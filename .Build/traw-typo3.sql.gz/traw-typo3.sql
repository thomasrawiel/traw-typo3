-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `db_mountpoints` longtext DEFAULT NULL,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1729257908,1725456837,0,0,'','mygroup','','','',NULL,'','','','','','','','readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile','options.pageTree.label.15 {\r\n    label = Campaign A\r\n    color = #ff0000\r\n}','',0,'0');
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(512) DEFAULT '',
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `TSconfig` longtext DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1729257914,1717850278,0,0,0,0,NULL,'traw-admin',0,'$argon2i$v=19$m=65536,t=16,p=1$TmZicDFtbDVxTEc0SnpkVg$dcCuRLxrR7xTb56Mpn2fioa1Hf84AskfENo+3s+Dh1o',1,'1','default','traw@traw-admin.com',NULL,0,'TRAW Admin',NULL,'','a:23:{s:10:\"moduleData\";a:14:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";a:5:{i:0;s:4:\"TRAW\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=0e0a5e50beeabdea679e75fd391554ed8deb7b60&id=1\";}}i:1;s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";}s:16:\"opendocs::recent\";a:8:{s:32:\"ffbd6ae78a9aa555f88d6295c30fb80c\";a:5:{i:0;s:22:\"Testing all parameters\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:10;s:3:\"pid\";i:16;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=0e0a5e50beeabdea679e75fd391554ed8deb7b60&id=16#element-tt_content-10\";}s:32:\"4869cf322808343c3d6ca616a691b6a3\";a:5:{i:0;s:3:\"asd\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:1;s:3:\"pid\";i:31;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:71:\"/typo3/module/web/layout?token=f9488a5820f62a957e2d4f508c90e633c10393bb\";}s:32:\"94196659226eb2fdae4ef3740d8c539d\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_address\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_address%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_address\";s:3:\"uid\";i:2;s:3:\"pid\";i:27;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:92:\"/typo3/module/web/list?token=c23c6843dbae3b23807be67cd4296b4bfc74c613&id=27&table=&pointer=1\";}s:32:\"750043f9a02785cc6557d2efe33fd403\";a:5:{i:0;s:5:\"Image\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:0:\"\";}s:32:\"1467e679afd3ae18833d97989b82f39a\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:38;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B38%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:38;s:3:\"pid\";i:24;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:78:\"/typo3/module/web/layout?token=480ffc6730920e04bc19fe648b2a96ec9f152738&id=24&\";}s:32:\"d4da84319118bf151b548cc61b911282\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:35;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B35%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:35;s:3:\"pid\";i:24;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:71:\"/typo3/module/web/layout?token=9960a6c878c80fcaf561d64347e9ccff16a96708\";}s:32:\"86205c5935270b8ee413592ec1b62292\";a:5:{i:0;s:29:\"TRAW Theme Main Test Instance\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:73:\"/typo3/module/web/ts?token=7da5109cc216b33c5f12c9250c9f81732d43d329&id=1&\";}s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";a:5:{i:0;s:4:\"TRAW\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:75:\"/typo3/module/web/list?token=84e461a5a7ea6c1151c4cd174c8d8557c97df9d8&id=1&\";}}s:6:\"web_ts\";a:1:{s:6:\"action\";s:17:\"typoscript_active\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}}s:23:\"backend_user_management\";a:1:{s:13:\"defaultAction\";s:4:\"list\";}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:13:\"system_config\";a:1:{s:4:\"tree\";s:14:\"eventListeners\";}s:16:\"browse_links.php\";a:1:{s:10:\"expandPage\";s:2:\"22\";}s:9:\"clipboard\";a:5:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";s:6:\"normal\";a:2:{s:2:\"el\";a:1:{s:13:\"tt_content|10\";s:1:\"1\";}s:4:\"mode\";s:4:\"copy\";}}s:16:\"media_management\";a:5:{s:13:\"displayThumbs\";b:1;s:9:\"clipBoard\";b:1;s:4:\"sort\";s:4:\"file\";s:7:\"reverse\";b:0;s:8:\"viewMode\";s:4:\"list\";}s:18:\"list/displayFields\";a:1:{s:5:\"pages\";a:2:{i:0;s:5:\"title\";i:1;s:6:\"hidden\";}}s:8:\"web_list\";a:3:{s:9:\"clipBoard\";b:1;s:9:\"searchBox\";s:1:\"0\";s:15:\"collapsedTables\";a:0:{}}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:334:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:0:\"\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:9:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_3\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";s:3:\"0_6\";s:1:\"0\";s:3:\"0_8\";s:1:\"1\";s:3:\"0_9\";s:1:\"1\";s:4:\"0_15\";s:1:\"1\";s:4:\"0_14\";s:1:\"1\";s:4:\"0_19\";s:1:\"1\";}}}}s:15:\"moduleSessionID\";a:14:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"9c479c702ff3260ca84b12af8cd03df17239ceb7\";s:10:\"FormEngine\";s:40:\"9c479c702ff3260ca84b12af8cd03df17239ceb7\";s:16:\"opendocs::recent\";s:40:\"9c479c702ff3260ca84b12af8cd03df17239ceb7\";s:6:\"web_ts\";s:40:\"948aef481229693c00177263409613ac6b32d743\";s:25:\"web_typoscript_infomodify\";s:40:\"b28c0b7e6ea091ef0b4ad8a1ed7ed20b2aed738d\";s:23:\"backend_user_management\";s:40:\"0ed5733ea5f42d7fa056414279d3c77a61f98a7d\";s:17:\"typoscript_active\";s:40:\"dfbc0c969429acd75e569e8acc35a7cfa6475c0f\";s:13:\"system_config\";s:40:\"9c479c702ff3260ca84b12af8cd03df17239ceb7\";s:16:\"browse_links.php\";s:40:\"948aef481229693c00177263409613ac6b32d743\";s:9:\"clipboard\";s:40:\"03b2dd884bffcc43cdc0be3bbf4c5439b0dd13b3\";s:16:\"media_management\";s:40:\"64079ccd1b0abc96dd45de210a1909b5409b2cef\";s:18:\"list/displayFields\";s:40:\"0ed5733ea5f42d7fa056414279d3c77a61f98a7d\";s:8:\"web_list\";s:40:\"b8da129f4b71352c4cd25bade9bb8fa4c56866b9\";s:10:\"system_log\";s:40:\"ff55f8bf7377a367ff6e430868849023de18a9e2\";}s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:4:\"lang\";s:0:\"\";s:11:\"startModule\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:10:\"copyLevels\";s:0:\"\";s:18:\"resetConfiguration\";s:0:\"\";s:12:\"mfaProviders\";s:0:\"\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:9:\"feediting\";i:1;s:10:\"inlineView\";s:430:\"{\"sys_file_metadata\":{\"2\":{\"sys_file_reference\":{\"1\":4,\"5\":\"5\"}}},\"tt_content\":{\"31\":{\"sys_file_reference\":[\"2\"]},\"NEW672c9d81aef87707155616\":{\"sys_file_reference\":[6]},\"37\":{\"sys_file_reference\":[\"6\"]}},\"tx_powermail_domain_model_form\":{\"NEW681f79dc97c80349664767\":{\"tx_powermail_domain_model_field\":[1],\"tx_powermail_domain_model_page\":[1]},\"1\":{\"tx_powermail_domain_model_page\":[\"1\"],\"tx_powermail_domain_model_field\":[\"\",2]}}}\";s:11:\"colorScheme\";s:5:\"light\";s:5:\"theme\";s:7:\"classic\";s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"300\";}}',NULL,NULL,1,NULL,0,NULL,NULL,1749546093,''),
(3,0,1730976801,1730976801,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$NndKby5uTGQvTk9LYzBhTA$KoYM0hmiqWouIdzAgJyeXDvC+NTC2I6Y/Ci4pd5R8Eg',1,'','default','',NULL,3,'',NULL,'','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}','',NULL,1,NULL,0,NULL,NULL,0,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'28__0_0_1_1',1752138527,'x��VK��6�/:Y�^[���H��\r��A����2����Tc���ç(i��-����h�/Z��gVdw��7ų,�E2�*�c�jwg�ޒR�\"QRѶ7@���y���ڗRTTA�����I\r(0RR�{fU��E�R�R���o�U1�+��Z���\"+�4���źZ35�-�/�A����qT��������O^j��ȫ$\r���@���\ru4Yڑ�\n���|e�/K=�L��l㰊�N�a�B�$/���ZAxdA�����eQ�����D+� A���FX��4zH�4�Μ��ߔH�|�8���#��^5�(���>|V�IL�t�������5c~���w\'V���N&�d\n�c���(����?�����+Q��<�a��H˫����v�>\Zz����	��AEL�h��E����zᢒ��[��DWu$PG�=�ZF\"��ռ��L:N$PQ�����@~�?�}�ệ��E{�T���\nB?��a���I���0<�XF2�\n�<H��,����~\"�p�,��qb�Q�\"\'�[ҏ���F�aZi\0	o��5ٮ#��8i����`�j3$:O\Z��ؓ,�cϖ%a]�����)��`0O]C����XE&vp��)�Fe3�������_�\"G[*�E\n�o\Z~���z�\nʲܬ5�c�ƲU�������B\\��B�j|+��f֕��+iC\Z�=��S�������������p�F��CN~\"^t`��.��:��Ѫ��on7y�Y��,�m�u��W�s~��V��`��ҭ^u~Σ#o�J0�����8+�Ė\n-`ȸ��Ͼ<�����b��2�Cm4������N�e-��v�2�a�0�\r֊}�39�v�� �r���6P~j6\'_���hC;���~�]��Cz�:��>n�r��\r����6{�*^i�����C�7؛q/�RmjHߡ���H����<����aIzֳ���+��7 �����|��7Y��0����0��y�m�]���jה$�Gʺ��y�\'�i$���͟܇X���_���B�Z�yg�Au:o�K�h�o��$T�W;,���]��X\Zږ��?pT���ux'),
(2,'1__0_0_1_1',1752138916,'x�mVKo�6�/:)���9����.�ڋ�\'�i��D�|�1����ķ���<șoDP�>8�_j��C��,��G��\"MN�AzD�ц�Ӣn���];M�(1�i��i]��Gд��l`��^�R&��*��#c������JZ�Q����i��lw��C6�R���N��p	�~8�r3���6��>k<�[�3lS�M������b�\\�ZZ����:�f��9`����}0�<j��QQy4�UP�/�����l�yù��r��\\I�j�a����=J{9��Ď)xG<pq��a#�pw��`{��+�Iq��9;T�yt��\0��p���7���P��Nō�Q�!d��\"�qґ�ORQ�u��ʿ1���D���ܭ4\0gi�#�N?�	�;��qnQbX�w�����N\n��J�x�?Q=3���soG�\"�/�k<_�����ӌ�����0a��n���FIm������\Z�sx�\r���ۍ��4Ow{/��-r�8��&�	�P6�ʍ�M�l>NYg��mX-l/f���уY����l6�\0�t9��Cx�|��Ԩ��L%�kV_2/��3�j���~��O�á9�y\'�9x���������\'�@\n>���R���y�����͜�����0����V	��K9�F�I���Ld���x2�2]\'��:����@d���EY=��vh�4\"��������n�_{����on=��維�G�O$����\')��U{��=�d��������^\\K��l5]qIژ���Ȼ�>�����L��.���K3\Z�?.��a�^Z��\\u�a-�A=sO��}�g���O����.VV��9�\'���U��eG䤞*�l�!(|Y��!T��I��|��Aӭ�5�b�M�%�.Wb��[1��(�c�{F7�d��rW�=X,M��dǑ�sH��?�l���﨤��^,�Э_�������I2');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'28__0_0_1_1','pageId_1'),
(2,'28__0_0_1_1','pageId_28'),
(3,'1__0_0_1_1','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_category`
--

DROP TABLE IF EXISTS `cache_ttaddress_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_category`
--

LOCK TABLES `cache_ttaddress_category` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_category_tags`
--

DROP TABLE IF EXISTS `cache_ttaddress_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_category_tags`
--

LOCK TABLES `cache_ttaddress_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_geocoding`
--

DROP TABLE IF EXISTS `cache_ttaddress_geocoding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_geocoding` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_geocoding`
--

LOCK TABLES `cache_ttaddress_geocoding` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_geocoding_tags`
--

DROP TABLE IF EXISTS `cache_ttaddress_geocoding_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_geocoding_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_geocoding_tags`
--

LOCK TABLES `cache_ttaddress_geocoding_tags` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` longtext DEFAULT NULL,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` longtext DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `slug` text DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1749545775,1717850306,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'TRAW',1,'',1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1730977016,NULL,'',0,'','','',0,0,0,0,0,'pagets__MainPage','pagets__3col','EXT:traw_theme/Configuration/TSConfig/Page.tsconfig',0,0,0,'/','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(2,0,1717852943,1717850354,0,0,0,0,'',512,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Subpage 1',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'pagets__MainPage','pagets__MainPage','EXT:traw_theme/Configuration/TSConfig/BackendLayouts.typoscript,EXT:traw_theme/Configuration/TSConfig/Page.typoscript',0,0,0,'/','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(3,0,1717852930,1717850358,0,0,0,0,'',768,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Subpage 2',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'pagets__MainPage','pagets__MainPage','EXT:traw_theme/Configuration/TSConfig/BackendLayouts.typoscript,EXT:traw_theme/Configuration/TSConfig/Page.typoscript',0,0,0,'/','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(4,0,1717852921,1717850366,0,0,0,0,'',1024,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Subpage 3',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'pagets__MainPage','pagets__MainPage','EXT:traw_theme/Configuration/TSConfig/BackendLayouts.typoscript,EXT:traw_theme/Configuration/TSConfig/Page.typoscript',0,0,0,'/','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(5,0,1717852908,1717850383,0,0,0,0,'',1280,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Subpage 4',1,NULL,1,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'pagets__MainPage','pagets__MainPage','EXT:traw_theme/Configuration/TSConfig/BackendLayouts.typoscript,EXT:traw_theme/Configuration/TSConfig/Page.typoscript',0,0,0,'/','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(6,1,1718546611,1718539597,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"tx_hreflang_pages_pages\":\"\",\"tx_hreflang_pages_xdefault\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Image',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718539625,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/image','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(7,15,1718546718,1718539620,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"tx_hreflang_pages_pages\":\"\",\"tx_hreflang_pages_xdefault\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Extension loaded',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546718,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/other/extension-loaded','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(9,15,1718546850,1718544396,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"tx_hreflang_pages_pages\":\"\",\"tx_hreflang_pages_xdefault\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Date Range',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1723629278,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/other/date-range','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(10,6,1718546738,1718546646,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Lazysizes',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546738,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/image/lazysizes','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(11,6,1718546736,1718546659,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Imagesize',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546736,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/image/imagesize','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(12,6,1718546740,1718546670,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Svg Content',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546740,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/image/svg-content','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(13,6,1718546742,1718546676,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Svg',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546742,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/image/svg','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(14,1,1718546690,1718546688,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Link',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/link','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(15,1,1718546770,1718546705,0,0,0,0,'',768,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"tx_hreflang_pages_pages\":\"\",\"tx_hreflang_pages_xdefault\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Other ViewHelpers',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546770,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/other','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(16,14,1718546733,1718546731,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Parameter parts',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1724835394,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/link/parameter-parts','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(17,15,1718546799,1718546797,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Pipe2Br',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1723637419,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/other/pipe2br','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(18,15,1718546836,1718546833,0,0,0,0,'0',384,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Phone number',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1723640210,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/other/phone-number','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(19,1,1718546873,1718546871,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Utilities',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/utilities','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(20,19,1718546915,1718546900,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'General Utility',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1725454228,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/utilities/general-utility','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(21,19,1718546913,1718546911,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Configuration Utility',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1718546913,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/utilities/configuration-utility','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(22,1,1721204504,1721204381,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Addresses',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/addresses','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(23,1,1721204494,1721204391,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Product Groups',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/product-groups','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(24,1,1721204914,1721204911,0,0,0,0,'0',896,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Address',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1735644068,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/address','',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),
(25,6,1736329274,1730977037,0,0,0,0,'',192,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,27,0,'Responsive Images',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1736329274,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/image/responsive-images','',0,0,'',NULL,0,'',NULL,0,'','',0.5,''),
(26,14,1736329136,1736329044,0,1,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,27,0,'Telephone',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1736329047,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/link/telephone','',0,0,'',NULL,0,'',NULL,0,'','',0.5,''),
(28,1,1737971894,1737971877,0,0,0,0,'0',960,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,27,0,'Extensions',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1737971894,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/extensions','',0,0,'',NULL,0,'',NULL,0,'','',0.5,''),
(29,28,1737971892,1737971886,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,27,0,'Supheader',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,1737974349,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/extensions/supheader','',0,0,'',NULL,0,'',NULL,0,'','',0.5,''),
(30,28,1746893255,1746893255,0,1,0,0,'0',128,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,27,0,'Powermail',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/extensions/powermail','',0,0,'',NULL,0,'',NULL,0,'','',0.5,''),
(31,1,1747239144,1747239144,0,1,0,0,'0',1152,NULL,0,0,0,0,NULL,'',0,0,0,0,1,1,31,27,0,'News',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/news','',0,0,'',NULL,0,'',NULL,0,'','',0.5,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` int(11) NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1725445707,1725445707,0,1,5,0,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1717850216,1717850216),
(2,0,1725452158,1725452158,0,1,4,0,'/videos/BigBuckBunny_320x180.mp4','fb11aa00e27ab83a7a9946a5493eb1552577e2d7','c04e2417e7d682acf27eadc6b40188a2ab7b88c3','mp4','video/mp4','BigBuckBunny_320x180.mp4','2ef07c959535fb41783aa7954e34844c1a9d5f6c',64657027,1725452158,1725452158),
(3,0,1725452849,1725452849,0,1,2,0,'/user_upload/1200px-Big_buck_bunny_poster_big.jpg','424ca75548d98e57fccb36b060060c8f2dfd03ab','19669f1e02c2f16705ec7587044c66443be70725','jpg','image/jpeg','1200px-Big_buck_bunny_poster_big.jpg','07081176792c19fbd3fed4d2ced97c99457f27be',248935,1725452849,1725452849),
(4,0,1725455189,1725455189,0,1,1,0,'/user_upload/1.gw-uebergangsfilm_serioes_ut_2014.vtt','72c0dab795dd07d8ea4182d512944fa68595113c','19669f1e02c2f16705ec7587044c66443be70725','vtt','text/vtt','1.gw-uebergangsfilm_serioes_ut_2014.vtt','2caf74c940c629d5720c77de827bbf36fc5d3f02',365,1725455189,1725455189),
(5,0,1728287722,1728287723,0,1,2,0,'/qr-codes/test-8-24.svg','b77d730bd54f6a7755a64d95fcf6f118fbf09aca','2a49590351bde463c3f9e9c9d0f45cb949ba2868','svg','image/svg+xml','test-8-24.svg','87eba3bc8a29dea4a2614578f2dd58dff05195f6',19228,1728287722,1728287722),
(6,0,1736329235,1736329235,0,1,2,0,'/qr-codes/test-new6703f7e8e7066638707911-24.svg','f8001d626cdc3706f99f44f598bb4b5711162bae','2a49590351bde463c3f9e9c9d0f45cb949ba2868','svg','image/svg+xml','test-new6703f7e8e7066638707911-24.svg','c1ed47595479ea21e9c18943aa32244b8030286f',11036,1736329235,1736329235),
(7,0,1735644525,1735644525,0,1,2,0,'/qr-codes/24_24.svg','cef6c112991adb525f9b28accf02347cf25a9f4e','2a49590351bde463c3f9e9c9d0f45cb949ba2868','svg','image/svg+xml','24_24.svg','8faab08cbd15a8119faf278148c5d478738f501f',29724,1735644525,1735644525),
(8,0,1736329235,1736329235,0,1,2,0,'/qr-codes/traw-admin.svg','97d8eb8c3041d471eefa19b49bbc453418e65a30','2a49590351bde463c3f9e9c9d0f45cb949ba2868','svg','image/svg+xml','traw-admin.svg','8faab08cbd15a8119faf278148c5d478738f501f',29724,1736329235,1736329235);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `content_creation_date` bigint(20) NOT NULL DEFAULT 0,
  `content_modification_date` bigint(20) NOT NULL DEFAULT 0,
  `visible` smallint(5) unsigned NOT NULL DEFAULT 1,
  `status` varchar(24) DEFAULT '',
  `keywords` longtext DEFAULT NULL,
  `caption` longtext DEFAULT NULL,
  `creator_tool` varchar(255) NOT NULL DEFAULT '',
  `download_name` varchar(255) NOT NULL DEFAULT '',
  `creator` varchar(255) NOT NULL DEFAULT '',
  `publisher` varchar(120) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `copyright` longtext DEFAULT NULL,
  `location_country` varchar(45) NOT NULL DEFAULT '',
  `location_region` varchar(45) NOT NULL DEFAULT '',
  `location_city` varchar(45) NOT NULL DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `ranking` int(10) unsigned NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `unit` varchar(3) NOT NULL DEFAULT '',
  `duration` int(11) NOT NULL DEFAULT 0,
  `color_space` varchar(4) NOT NULL DEFAULT '',
  `pages` int(10) unsigned DEFAULT 0,
  `language` varchar(45) NOT NULL DEFAULT '',
  `fe_groups` longtext DEFAULT NULL,
  `tracks` int(11) NOT NULL DEFAULT 0,
  `poster` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1725445707,1725445707,0,0,NULL,'',0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(2,0,1725458512,1725452158,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"duration\":\"\",\"poster\":\"\",\"tracks\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,2,NULL,0,0,NULL,NULL,0,0,0,1,'1',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(3,0,1725452849,1725452849,0,0,NULL,'',0,0,0,0,3,NULL,1200,1698,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(4,0,1725455189,1725455189,0,0,NULL,'',0,0,0,0,4,NULL,0,0,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(5,0,1728287722,1728287722,0,0,NULL,'',0,0,0,0,5,NULL,33,33,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(6,0,1735643257,1728313447,0,0,NULL,'',0,0,0,0,6,NULL,25,25,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(7,0,1735644524,1735644524,0,0,NULL,'',0,0,0,0,7,NULL,41,41,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0),
(8,0,1735644670,1735644670,0,0,NULL,'',0,0,0,0,8,NULL,41,41,NULL,NULL,0,0,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,NULL,'',0,'',0,'',NULL,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1725452160,1725452160,1,2,'',NULL,'','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','2ef07c959535fb41783aa7954e34844c1a9d5f6c','Image.CropScaleMask','5f90e1912f',0,0),
(2,1725452160,1725452160,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','2ef07c959535fb41783aa7954e34844c1a9d5f6c','Image.CropScaleMask','19c8b180fb',0,0),
(3,1725452166,1725452166,1,2,'/_processed_/e/3/preview_BigBuckBunny_320x180_1c174f7480.png','preview_BigBuckBunny_320x180_1c174f7480.png',NULL,'a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}','55d97d4e532f03dbc8a5053eac06a25a43ca2e20','2ef07c959535fb41783aa7954e34844c1a9d5f6c','Image.Preview','1c174f7480',56,40),
(4,1725452698,1725452698,1,2,'/_processed_/e/3/preview_BigBuckBunny_320x180_3a402df5b7.png','preview_BigBuckBunny_320x180_3a402df5b7.png',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','2ef07c959535fb41783aa7954e34844c1a9d5f6c','Image.Preview','3a402df5b7',56,40),
(5,1725452883,1725452849,1,3,'/_processed_/0/d/preview_1200px-Big_buck_bunny_poster_big_b836cf3c25.jpg','preview_1200px-Big_buck_bunny_poster_big_b836cf3c25.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','07081176792c19fbd3fed4d2ced97c99457f27be','Image.Preview','b836cf3c25',45,64),
(6,1725452849,1725452849,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_b25d619336.jpg','csm_1200px-Big_buck_bunny_poster_big_b25d619336.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','b25d619336',107,150),
(7,1725452849,1725452849,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_6bafd9a7fd.jpg','csm_1200px-Big_buck_bunny_poster_big_6bafd9a7fd.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','6bafd9a7fd',32,45),
(8,1725453780,1725453780,1,2,'',NULL,'','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','2ef07c959535fb41783aa7954e34844c1a9d5f6c','Image.CropScaleMask','a87fd0ec21',0,0),
(9,1730977158,1725453836,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_6885358f98.jpg','csm_1200px-Big_buck_bunny_poster_big_6885358f98.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','6885358f98',32,32),
(10,1725453837,1725453836,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_dbf53c8f1a.jpg','csm_1200px-Big_buck_bunny_poster_big_dbf53c8f1a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','dbf53c8f1a',81,115),
(11,1725455154,1725455154,1,3,'/_processed_/0/d/preview_1200px-Big_buck_bunny_poster_big_81bbd8384b.jpg','preview_1200px-Big_buck_bunny_poster_big_81bbd8384b.jpg','','a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}','55d97d4e532f03dbc8a5053eac06a25a43ca2e20','07081176792c19fbd3fed4d2ced97c99457f27be','Image.Preview','81bbd8384b',106,150),
(12,1725458777,1725458777,1,3,'',NULL,'','a:1:{s:4:\"crop\";N;}','666a326c87172a7bbf37c1c582f346d1f06ab88a','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','d32f2831ed',0,0),
(13,1729257644,1729257644,1,5,'',NULL,'','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','87eba3bc8a29dea4a2614578f2dd58dff05195f6','Image.CropScaleMask','0a9b9c8bbd',32,32),
(14,1729257644,1729257644,1,5,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','87eba3bc8a29dea4a2614578f2dd58dff05195f6','Image.Preview','22893c6d9c',33,33),
(17,1730977157,1730977157,1,5,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','87eba3bc8a29dea4a2614578f2dd58dff05195f6','Image.CropScaleMask','4c1c8a6e4f',33,33),
(19,1730977592,1730977592,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_d6e3fbdeff.jpg','csm_1200px-Big_buck_bunny_poster_big_d6e3fbdeff.jpg',NULL,'a:9:{s:5:\"width\";i:768;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 85\";s:4:\"crop\";N;}','1ef0bdcb0c34ba1ec8afc00f6bac38fe26dc186c','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','d6e3fbdeff',768,1087),
(20,1730977592,1730977592,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_2c189f59e3.jpg','csm_1200px-Big_buck_bunny_poster_big_2c189f59e3.jpg',NULL,'a:9:{s:5:\"width\";i:768;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 60\";s:4:\"crop\";N;}','fd9fa14fe341593cb9b1d335b9febb1b3fd1118a','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','2c189f59e3',768,1087),
(21,1730977592,1730977592,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_2039426ca0.jpg','csm_1200px-Big_buck_bunny_poster_big_2039426ca0.jpg',NULL,'a:9:{s:5:\"width\";i:480;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 50\";s:4:\"crop\";N;}','7ee602c53e3f197f4ba707a3f77743436f57da8f','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','2039426ca0',480,679),
(22,1730977592,1730977592,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_7195ecad32.jpg','csm_1200px-Big_buck_bunny_poster_big_7195ecad32.jpg',NULL,'a:9:{s:5:\"width\";i:960;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 50\";s:4:\"crop\";N;}','866cde2b75e163463fb30e1cb3368cf9ac6727de','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','7195ecad32',960,1358),
(23,1730977592,1730977592,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_7298500bc8.jpg','csm_1200px-Big_buck_bunny_poster_big_7298500bc8.jpg',NULL,'a:9:{s:5:\"width\";i:600;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 85\";s:4:\"crop\";N;}','118ab07e3683dcbbcd9bfd0114271686e94d357a','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','7298500bc8',600,849),
(24,1730977689,1730977689,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_ce145de773.jpg','csm_1200px-Big_buck_bunny_poster_big_ce145de773.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1000;s:9:\"maxHeight\";i:1000;s:4:\"crop\";N;}','1097b19f7c94bc1bdd2bf43bfc22198c30890d2e','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','ce145de773',707,1000),
(25,1730977689,1730977689,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_b0c401be9a.jpg','csm_1200px-Big_buck_bunny_poster_big_b0c401be9a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:300;s:9:\"maxHeight\";i:300;s:4:\"crop\";N;}','e239fcbae08ee546b841850592062fe370de3336','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','b0c401be9a',212,300),
(26,1730977712,1730977711,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_61c787d01e.jpg','csm_1200px-Big_buck_bunny_poster_big_61c787d01e.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:-1.6973125884016973;s:4:\"\0*\0y\";d:319.4669999999999;s:8:\"\0*\0width\";d:1200;s:9:\"\0*\0height\";d:1200;}}','0307ae24a807be9b1e85202145027caed3092266','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','61c787d01e',150,150),
(27,1730977712,1730977711,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_d12b308f1a.jpg','csm_1200px-Big_buck_bunny_poster_big_d12b308f1a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:798.6664922206505;s:8:\"\0*\0width\";d:1198.3026874115983;s:9:\"\0*\0height\";d:898.7270155586987;}}','ae5ab56526a19873028ea8eabde4e35411ff4e7d','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','d12b308f1a',200,150),
(28,1730977713,1730977711,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_3c96da5603.jpg','csm_1200px-Big_buck_bunny_poster_big_3c96da5603.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:844.4137383309759;s:8:\"\0*\0width\";d:1196.6053748231966;s:9:\"\0*\0height\";d:673.0905233380481;}}','ee80323ec3f134202c19c1178577bacb39bc72c9','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','3c96da5603',267,150),
(29,1730977716,1730977716,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_b9eed84d4f.jpg','csm_1200px-Big_buck_bunny_poster_big_b9eed84d4f.jpg',NULL,'a:9:{s:5:\"width\";i:768;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 85\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:-1.6973125884016973;s:4:\"\0*\0y\";d:319.224;s:8:\"\0*\0width\";d:1200;s:9:\"\0*\0height\";d:1200.4859999999999;}}','e53c2188aab93da7679e2393dea993671b4b6905','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','b9eed84d4f',768,768),
(30,1730977716,1730977716,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_7e2dec5a7a.jpg','csm_1200px-Big_buck_bunny_poster_big_7e2dec5a7a.jpg',NULL,'a:9:{s:5:\"width\";i:768;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 85\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:798.06;s:8:\"\0*\0width\";d:1198.3026874115983;s:9:\"\0*\0height\";d:899.94;}}','e18da7e4fa0d61c6cca06d1e2d73f57384a709b8','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','7e2dec5a7a',768,577),
(31,1730977716,1730977716,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_b5d384bf07.jpg','csm_1200px-Big_buck_bunny_poster_big_b5d384bf07.jpg',NULL,'a:9:{s:5:\"width\";i:768;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 60\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:843.906;s:8:\"\0*\0width\";d:1196.6053748231966;s:9:\"\0*\0height\";d:674.106;}}','cf6a41e385e4a705a0a78447bb197ac72e1c7262','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','b5d384bf07',768,433),
(32,1730977716,1730977716,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_2994dd5856.jpg','csm_1200px-Big_buck_bunny_poster_big_2994dd5856.jpg',NULL,'a:9:{s:5:\"width\";i:480;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 50\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:843.906;s:8:\"\0*\0width\";d:1196.6053748231966;s:9:\"\0*\0height\";d:674.106;}}','a48211a27bbcdd3ae5cdf8dce0c7f20f9a99596b','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','2994dd5856',480,270),
(33,1730977716,1730977716,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_1afcc4fd01.jpg','csm_1200px-Big_buck_bunny_poster_big_1afcc4fd01.jpg',NULL,'a:9:{s:5:\"width\";i:960;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 50\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:843.906;s:8:\"\0*\0width\";d:1196.6053748231966;s:9:\"\0*\0height\";d:674.106;}}','6e7835dcb86c637b790079cd126ad70858fcae80','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','1afcc4fd01',960,541),
(34,1730977716,1730977716,1,3,'/_processed_/0/d/csm_1200px-Big_buck_bunny_poster_big_78b0d12065.jpg','csm_1200px-Big_buck_bunny_poster_big_78b0d12065.jpg',NULL,'a:9:{s:5:\"width\";i:600;s:6:\"height\";N;s:4:\"minW\";N;s:4:\"minH\";N;s:4:\"maxW\";N;s:4:\"maxH\";N;s:18:\"treatIdAsReference\";i:1;s:6:\"params\";s:12:\" -quality 85\";s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:-1.6973125884016973;s:4:\"\0*\0y\";d:319.224;s:8:\"\0*\0width\";d:1200;s:9:\"\0*\0height\";d:1200.4859999999999;}}','a2d406a37493b1aa8438b032b4f423cd4c07782c','07081176792c19fbd3fed4d2ced97c99457f27be','Image.CropScaleMask','78b0d12065',600,600);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` text NOT NULL DEFAULT '',
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mute` smallint(6) NOT NULL DEFAULT 0,
  `showinfo` smallint(6) NOT NULL DEFAULT 0,
  `controls` smallint(6) NOT NULL DEFAULT 0,
  `controlslist` smallint(6) NOT NULL DEFAULT 11,
  `loop` smallint(6) NOT NULL DEFAULT 0,
  `picinpic` smallint(6) NOT NULL DEFAULT 0,
  `track_language` varchar(30) NOT NULL DEFAULT '',
  `track_type` varchar(30) NOT NULL DEFAULT '',
  `track_label` varchar(255) NOT NULL DEFAULT '',
  `track_default` smallint(6) NOT NULL DEFAULT 0,
  `poster` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,0,1725458512,1725452895,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,2,'sys_file_metadata','poster',1,NULL,NULL,NULL,'','{\"desktop\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tablet\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"mobile\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,0,0,11,0,0,'','','',0,0),
(2,20,1725459165,1725454228,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"poster\":\"\",\"autoplay\":\"\",\"mute\":\"\",\"loop\":\"\",\"showinfo\":\"\",\"controls\":\"\",\"controlslist\":\"\",\"picinpic\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,2,31,'tt_content','assets',1,NULL,NULL,NULL,'','',0,0,0,0,11,0,0,'','','',0,0),
(3,20,1725459165,1725454228,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,2,'sys_file_reference','poster',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,0,0,11,0,0,'','','',0,0),
(5,0,1725458512,1725458512,0,0,0,0,NULL,'',0,0,0,0,4,2,'sys_file_metadata','tracks',1,NULL,NULL,NULL,'','',0,0,0,0,11,0,0,'','','',0,0),
(6,25,1730977711,1730977165,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,3,37,'tt_content','assets',1,NULL,NULL,NULL,'','{\"desktop\":{\"cropArea\":{\"height\":0.707,\"width\":1,\"x\":-0.0014144271570014145,\"y\":0.188},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"tablet\":{\"cropArea\":{\"height\":0.53,\"width\":0.9985855728429985,\"x\":0,\"y\":0.47},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"mobile\":{\"cropArea\":{\"height\":0.397,\"width\":0.9971711456859972,\"x\":0,\"y\":0.497},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0,0,0,0,11,0,0,'','','',0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1717850311,1717850311,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
INSERT INTO `sys_http_report` VALUES
('035e4510-4b13-4098-83e1-24e72001f2ca',0,1737974349,1737974349,'csp-report','backend',1737974349233571,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-18-8wLs5_V3l8N9Kb5QxtOlIZFw-KNrVo1ZPoJVvIGBWiVOddkQStg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737974349233571&requestHash=054c5a8dd53198464b09e13169e1358c4400ed4d\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('04b4bb18-5152-4f56-8b5d-7cca484354ab',0,1723629279,1723629279,'csp-report','backend',1723629279134413,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B23%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-23\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B23%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-23\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-GwzqnJsPfL7mR1Mmd1uikrS6iEAHV0yNgQ33IZ5etQ70fS5rDQhACw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723629279134413\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('058ccd77-1144-4ce4-ad08-9bb0b033ea04',0,1721244423,1721244423,'csp-report','backend',1721244420485486,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B24%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Defacc7a8b13d1b18b142c014c1506fe73c007052%26id%3D24&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=24\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-dLvxbEDPxeYXppNL6Tg4G2TjWAixawZPnHpAYqMLwMOpnNhtLJV5YQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721244420485486\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('06fc8b23-5079-493c-9529-9c3de6815228',0,1747239281,1747239281,'csp-report','backend',1747239280590501,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B31%5D=new\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btx_news_domain_model_news%255D%255B31%255D%3Dnew\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-fmV9buecte3NN6HpgGDI-8eTvJksfAFzYYHvTuXYUgSyO66ajEJbKw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1747239280590501&requestHash=d6ff27f9cee344821a2ae8eba8676d2bcce807ae\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('07f94416-0cdc-4c67-be7e-0227d99b5126',0,1723627369,1723627369,'csp-report','backend',1723627368918973,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-6\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ob7ssOOJ0NQoJ-GYGYEHvuynOuYNE1g3tPgiDBnJjT1QQC9sSoQZLw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627368918973\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('0b37f89b-e398-437c-9e6e-354d58ebb9b1',0,1737976234,1737976234,'csp-report','backend',1737976233963597,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-BnPxCRoSp95wr_s3IrK1r0WgooudhUVqkjhKZcbcCFRE_c0psI6WxQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737976233963597&requestHash=0df8e52cdc7b95502fce8e476dbab08fc4d5ee7f\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('0b83cb87-d884-445f-970d-c2fbae01965a',0,1737971904,1737971904,'csp-report','backend',1737971902586437,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B29%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd%26id%3D29&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=29\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-AQkm8FKtgEfxFCLqvkw-VJ50dp1J08p9IKy-BzQJwpWxeVMhukTlWA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737971902586437&requestHash=b34ae6c71b93730efede54bfd1b625d6221c3ce6\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('0d256c5c-b753-40ac-8885-a6423d528141',0,1718542571,1718542571,'csp-report','backend',1718542571423869,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-0ZfGqfr58F11SILF3qT3Knfa0f2q_HUlzpFB4enTEpatwsneruXKag\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542571423869\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('0f998778-267b-4dd5-a6cf-cbb382a2bdf3',0,1718547814,1718547814,'csp-report','backend',1718547814277131,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%26%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%26%23element-tt_content-6\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-v3IjHJp0aGX1NzF9jyNbyPCcbMP9R0lOB7krYh1iLA5guVID2U7CSQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547814277131\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('0ff9f2c9-6379-49b6-98ad-3dfd944921bc',0,1723627444,1723627444,'csp-report','backend',1723627443816295,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B18%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-14%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-dPQPRZ30FqZdJhWmfEE6QIAx-ZdZAAFECZ9ry_lvYQ6koeUC1TQi3g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627443816295\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('111cb302-581d-4045-9206-905037e71757',0,1723627428,1723627428,'csp-report','backend',1723627427476965,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-14%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-SvKo0cX-5CsxVEJK4GvP-ZYb5Y5rEsMh98afdnIK4Tk3jl2WAnipyQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627427476965\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('11f70860-9aec-4633-9f4c-808d50580fbd',0,1723627376,1723627376,'csp-report','backend',1723627375992220,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B15%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-15\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-_Db17FxyaN8qVKRJj3XajKL6jiooOKqExF-Qf94NwSl-1Lnkhefqqw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627375992220\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('13f09fc4-de05-49b5-8206-b7c6e40a025f',0,1718547146,1718547146,'csp-report','backend',1718547146103159,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_extloaded&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-bWT9IWlhf7pW8kqsfR4No3sCdg7nPgsTzn3Q2YB77FEcYmzZkJdvhg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547146103159\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('14717373-3d5b-4afa-ba3b-d9e60bea42d1',0,1723626847,1723626847,'csp-report','backend',1723626847071425,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Fvbb2uWRvqSTzXLNFhrXUNVM-8mUm1n8SOB2n36sMe4PcAwIUoDl_A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626847071425\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('15bc736d-27d1-44fc-b461-fc000d329bb3',0,1737976190,1737976190,'csp-report','backend',1737976189903308,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-PZK4MXFSaK61BsQnb5eion9ZqW6W1XWA23A-YsHJI_f6C-2YG-7e8Q\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737976189903308&requestHash=699e8386569c7b7298ab551070e59d97f36c77cb\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('163613d0-d019-4227-bc2c-dfd9963287ee',0,1723627612,1723627612,'csp-report','backend',1723627611488110,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-19%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-obNYyq0vwvzDV5x5A6miKOc1Zo9u5YApuOQZD77sTW9_4r40C_jdvA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627611488110\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('17931935-91b0-4800-83e7-df7fc12ccd79',0,1728294337,1728294337,'csp-report','backend',1728294336449829,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/129.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-2gta57BQW-E2yKpTD6X2Gn4GaeYra5ljeKSmfzpygVKEc8I6ffnIvg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1728294336449829\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('17babe9e-7c3d-4829-abe5-1e6f59524a1e',0,1723627350,1723627350,'csp-report','backend',1723627349972011,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-_8pZyzVzLJJ05moYKv4VOHPuJFgYkBW9-JPG_BVrhEfHcfwSU9bSew\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627349972011\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('19d7cb41-0a3f-44a1-b081-71e8f4e6990d',0,1718546983,1718546983,'csp-report','backend',1718546982281621,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-oPQtqnSpUFbgyfLsAFeb_s7X-ypB5QooOgPPzLc9uCkSfE-dS7yq_Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718546982281621\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('1a207070-f721-44c0-bbea-5dfdfe3f4d49',0,1730977715,1730977715,'csp-report','backend',1730977711267581,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/130.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B37%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B37%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25&showPreview=1&popViewId=25\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-gDgXnJcOEon3So652Io1B8JAdN-vMH7uHzl99Dg5xeCcgMBNRSg0GQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1730977711267581\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('1ab9600a-2e59-4fe7-adec-25a3a68b0953',0,1728293851,1728293851,'csp-report','backend',1728293847679735,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/129.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=22&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-kpftSFFvxFYlC4zuYSTi7R74xGr-p6-4v8k2IKS83UYy5IRpFuMLKg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1728293847679735\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('1ab9687f-07ca-41eb-b99b-3ca6190c6b80',0,1737974347,1737974347,'csp-report','backend',1737974346369438,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Eijae9ANZ6DxkW5yA4uo5dzSDaMeJv0ayI_abCYqT5dWdSm8euXzFw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737974346369438&requestHash=a5acc9a7ad50249a084c8b30c7f270e536c97c98\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('1b190ced-e7eb-4677-97e8-b22372c5e8ce',0,1736935514,1736935514,'csp-report','backend',1736935514503812,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Dc23c6843dbae3b23807be67cd4296b4bfc74c613%26id%3D27%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B27%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Dc23c6843dbae3b23807be67cd4296b4bfc74c613%26id%3D27%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-iPAuBxslJ7aDQCwH5ZnipijSQxsv9UzbT-U7GoXK-oc1fdhvlFAz8A\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1736935514503812&requestHash=9d54bad3c150bdd791790c7ea36a972a3e5feefb\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('1d9bec76-4581-4438-a090-91ce4f23fae8',0,1723627226,1723627226,'csp-report','backend',1723627225518004,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-JQNl_wXGXJZbHgPHOqK1LZHCEhaQ2LJDRwbjhFDCe4gwpDhdQ2_k8w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627225518004\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('1ef492aa-72bd-4add-9822-ea6be2f254ae',0,1723626909,1723626909,'csp-report','backend',1723626909194471,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B15%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-6%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-gHihASbW5UpRY1gl-ESE9AV1pQNuZpu6pRviGs9ZTdMlA1y7LhQh7g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626909194471\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('1f1dce7f-a0fe-4bc2-8f6e-21902f9dd62d',0,1723623691,1723623691,'csp-report','backend',1723623686710897,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-9%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16&defVals%5Btt_content%5D%5BCType%5D=traw_extloaded&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-zJTZSu9-l9bpYTm67PNnuaxoW5SC6N56a2tp6Ud-I1SRL83jv2G19A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723623686710897\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('20ba9321-510d-4974-ae89-ac33a0e3dd03',0,1723637416,1723637416,'csp-report','backend',1723637416030533,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B25%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D17%23element-tt_content-25\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=17\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-KepCTNtxPqKDghs56_XTvna-vNLNVqrcBcYehFanDqs5AEdZVmM3gw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723637416030533\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('226e78e2-746a-464a-a7d4-74133c8dba9d',0,1736935513,1736935513,'csp-report','backend',1736935512878325,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B27%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Dc23c6843dbae3b23807be67cd4296b4bfc74c613%26id%3D27%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=27&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Dc23c6843dbae3b23807be67cd4296b4bfc74c613%26id%3D27%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-d7Nl_5PpcvKqNjCGpf26EMG2ipLWNI3Wvz98VnVCIMcg_bMXSN7ZuA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1736935512878325&requestHash=f7db4c78b2142b78550a0f8627cbf3569959f39c\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('247a8c2a-0ece-45d3-8a92-28a2b64079c1',0,1746893266,1746893266,'csp-report','backend',1746893265346278,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B30%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D19b3c4772f0a2af8d982b18361f40da21482ed84%26id%3D30&defVals%5Btt_content%5D%5BCType%5D=powermail_pi1&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=30\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ddhCf4Cj2KchpbC-Rnl-0HQEAEH1Tk9AYfT0LxoUscMBdA8gXT4yMQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1746893265346278&requestHash=d60a32729c75bda5aa36b5934288cdcfc3691202\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('267bda35-cf85-43c9-99c4-16699ed3668c',0,1737973477,1737973477,'csp-report','backend',1737973476671437,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-i7wqfpxAKLTnBF85D1kcXpb3Hm47pLr6dYcUbek6GK2bxFzFFZzhKg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973476671437&requestHash=6f267597d824b8bf1ab648cacc526bf859a8d0b5\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('28cd1cfd-f9ae-4218-9597-0631b23200c6',0,1723623703,1723623703,'csp-report','backend',1723623703255675,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-9%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16&defVals%5Btt_content%5D%5BCType%5D=traw_extloaded&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Hre4agan2huN9tbmQB0AferV98C8NENjUFkzKlSiRolymjP4cqlKmg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723623703255675\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('28d432c1-25b1-4b6c-8159-2fa8b365bf2a',0,1721204508,1721204508,'csp-report','backend',1721204507897937,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=22&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-en4SxBJwpvQrtrmn09l5X3nbwG8rvn9Uq5UaCxXPLKWpAweYt6uDow\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721204507897937\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('29cf65ef-a3e6-4d43-bdf3-b022a75d42bc',0,1737978633,1737978633,'csp-report','backend',1737978633403562,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-bb1BLPIbz4Id-RFl1x86iWE4bH0OPzJ3_ZdMDUwYqdIVHRy1m-k4Mw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737978633403562&requestHash=77d9485992b23e51ddc2e10c69674651b836fff9\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('29e8ed6d-d818-4e1b-8273-f338100208fd',0,1718542612,1718542612,'csp-report','backend',1718542611837708,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-LCw95jPYVua9na0xDJU64Kw-74CZ6K3RZn9kx_gqeq7UIl73XBKB8Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542611837708\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2a8bdd48-e720-46f9-bc55-419ca159d8b4',0,1718539632,1718539632,'csp-report','backend',1718539631883950,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B7%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7&defVals%5Btt_content%5D%5BCType%5D=textpic&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xBkgfU_cmGM2W0yUGFxWbt9HDM-4NMl2JP0VwCk_ZzKCJkulyn-3WQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718539631883950\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2aa6c3db-ccfb-4fb3-8f78-2397861fb76d',0,1723626771,1723626771,'csp-report','backend',1723626770992131,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-vNc7MV_2dwjYkZ2txz-KiCgWhIT_F41BXz0Dd1R2J6LHYqvmM14Pjg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626770992131\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2c231bc0-7321-41fb-a719-991d3a0a211e',0,1723627235,1723627235,'csp-report','backend',1723627234568157,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-qpAfFLtyvwHltKKHxMWZqK8gk3Wy2cDbjHkBUvxMIJ-hDwDnyU0OkQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627234568157\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2d2cd8a5-0058-43b7-a4de-7b5893d128b3',0,1721204881,1721204881,'csp-report','backend',1721204881422526,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=22&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ny7IMB1UI9WJjH2NOriIpypW8CXw1CrRyjsQgKgi6ICO4oW2eQjsCQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721204881422526\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2dc12c21-6616-4884-8061-d9af87802309',0,1718542632,1718542632,'csp-report','backend',1718542632425118,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-5\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-5\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-TpHetiWNzQ2yZrO-1TtvnOSto0Rg0sIYvqYqBIoU7UUAq27PKGkvHQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542632425118\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2ef7ac59-da4c-4c2c-a144-1bc4f6a1cac9',0,1718542563,1718542563,'csp-report','backend',1718542562374505,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B4%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B4%5D=edit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xua5vLB88AnygdZynqNiEzlI7fGytuXY-Tm6xcXBT_nBgGirDeMqMQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542562374505\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('2efe1eae-948e-4675-9bd1-513cedd85a16',0,1728294333,1728294333,'csp-report','backend',1728294332961987,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/129.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/list?id=22\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-pDwvfUGV7JHvm3IUvE3AEp9ykRW3iMu7_diNALpaM02abjepGZIIvQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1728294332961987\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('33385f6f-c144-4911-bc89-386d1fe127b7',0,1723627385,1723627385,'csp-report','backend',1723627385168954,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B15%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-15\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B15%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-15\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-XzMtYsmR2KVl5BZlzkxiuYJYXOErhtTCsojetG4Y2pfQ1bo7zOJxFw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627385168954\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('34d1b1a6-caea-488a-991e-ac1bd9df4f9d',0,1747240958,1747240958,'csp-report','backend',1747240946419257,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B2%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btx_news_domain_model_news%255D%255B2%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-I5cwKilwo93WxkXTyJeUAPlCKW5qKuFJ6BLl0Fcq4WBtG81MapGIUw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1747240946419257&requestHash=db57c4d2bad48655cead85ad4fe98c27226b31eb\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":6,\"column-number\":2002,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('34d8d81d-01d2-43dd-b28f-e6c5c13df6cf',0,1737980358,1737980358,'csp-report','backend',1737980357528346,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-AByDum0P5vtR7dOv2Y0BrNcTZ3hZ0biK2_qzVlPhuAwVp8EQLKQjwg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737980357528346&requestHash=f943df1e33da2bc4e246cb1e43a2531d606df1cd\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('34faaf03-22bd-457e-816f-b54b1bde9588',0,1735644023,1735644023,'csp-report','backend',1735644022658504,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Df63dc9a7dd1cd60192a3255b6570fb9069ce15ee%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Df63dc9a7dd1cd60192a3255b6570fb9069ce15ee%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-JHGUEYmpWcaEEIBIhtaej9xFSCvmcHZHkEJD0HbfT9zC_pdSCTUfWA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1735644022658504\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('37ae800d-dc90-49a0-8f61-c7ad99e8a0a2',0,1718541374,1718541374,'csp-report','backend',1718541373899958,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7&showPreview=1&popViewId=7\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-aQPbROhllB7JjoeChIxyuecDlhAR11-5VFD-89gOdKLFuRvs-eae-A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718541373899958\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('37b2e33d-dfe8-4115-b01c-2fed920a6dcd',0,1725458288,1725458288,'csp-report','backend',1725458285932534,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26%23element-tt_content-31\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=20\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-UHaR7vEpegnTJ1_PbQPX3bee3AXnDhkqBwgeXZmSgxGTZO8oU1DyKA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725458285932534\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('38b1f7d2-31ce-44c4-a92b-75a295f97e31',0,1723627341,1723627341,'csp-report','backend',1723627340316662,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-YXVDxr6VfKUd458erC6syLxItri73vDn5_MyRH1z5m5s9mAoeZQb7Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627340316662\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('3930476a-2dbb-4dcb-a8d0-9eb7a9d71747',0,1721204791,1721204791,'csp-report','backend',1721204789784619,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_address%255D%255B22%255D%3Dnew\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce--sLS0fiEB1Oab0UCQwt7nVrknP22Mhf1r5fiQ1LjqZj9XTrfEfpRuQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721204789784619\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('3931921a-f91b-4201-8f75-a7bcdaff57a4',0,1725454229,1725454229,'csp-report','backend',1725454229033943,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B20%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-R5e2L9rS5y6kvvLEXD-Su9ZQ6oPveSM7p6EX9CBk39jwK_02UejOmA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725454229033943\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('3960de94-e60f-47b5-8465-8ed21f00182e',0,1718547188,1718547188,'csp-report','backend',1718547187393041,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-42WgWLJRoXA0KXzGV5ZdWhaC-8A9RhAu8pFJxsxSB8SRQV7Yll5Rmg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547187393041\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('3a4ee95c-b8a7-4695-9be1-92d9c8880b70',0,1737976396,1737976396,'csp-report','backend',1737976395491504,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-09K_xxdFaQjZRwNnVCsBmRHGMk4tWzzSw2Ve4o-HKiwT9Fr_rp07wA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737976395491504&requestHash=4576e1e43b6489c2749aeaeaaf35cb928ebb071b\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('3c754505-8c2b-497f-9f28-9ab9e662e08d',0,1723626528,1723626528,'csp-report','backend',1723626527708923,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-u3KBrD-O6QCCy_s_rC_vtZ8QZbPVohtzuLBj7gpzwUaaoS7egXccUQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626527708923\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('3e8db069-d157-4d5d-89a4-167426b087b9',0,1723627538,1723627538,'csp-report','backend',1723627538026668,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B17%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-17\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B17%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-17\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-kV_hddk1IuDP4eylRidZq6jQnD9wAHYc2TD932beIXumAP16HWT50g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627538026668\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('423e488a-0730-446d-a93a-481e05993737',0,1737971911,1737971911,'csp-report','backend',1737971910960932,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd%26id%3D29\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd%26id%3D29\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-H1yEsdrRTF1cKzcBWaqq8obpuO2NQ4AuckBQ_VttLQB7cQgzd3azAw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737971910960932&requestHash=27694df8180fe9bc4b992c151689c4a089b64565\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('42b46ccb-b5b7-463b-8161-642d7cdb3a8a',0,1723627682,1723627682,'csp-report','backend',1723627681840495,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B22%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-21%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_parampart&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-cwYlmf99PQdIexJDS9mTe-8GQNa_SSqG7addok1GHynQ4WxMLiM3nA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627681840495\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('484fd9f4-4f90-4309-a7a4-c75d0f157447',0,1723627245,1723627245,'csp-report','backend',1723627244382416,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-14%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-0qqsEkWZvqdYQQxiqmCIYoi7Fo1Y7BLjdRfN7VMpTxChBIbe9Q7n9w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627244382416\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('49714605-e32a-437d-a6bf-249f981a72ee',0,1718542581,1718542581,'csp-report','backend',1718542580587126,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-5\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-9IVpCCMKIUBAGm4E0dQHqzXnrVawUGxEyhbg1lu7fxeKBLxxLb8YDw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542580587126\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('4ae4cb28-24d1-450b-a917-c4f0ce5d8adb',0,1723623089,1723623089,'csp-report','backend',1723623088420836,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D7%23element-tt_content-5\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-9IUyRcXHbsnfeCFyhmxqC4rebMPObt7waoyEQg02zKSCyhPaDGRb3g\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723623088420836\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('4ec06823-8ae9-4abc-a104-77cbf5df1646',0,1723623561,1723623561,'csp-report','backend',1723623560458024,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-1A9B_KJ4jZT0g9nnsbHbLmupI9sFFkP8FRunpkzLJi1gjRNUUhdHwg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723623560458024\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('5037a3e4-4e48-4c9e-8b12-638f8f2fb0a6',0,1718542599,1718542599,'csp-report','backend',1718542598914494,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B4%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-4\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xWWa7M9KtxpScHg5L7LehQv8di5f6XDSNkODDPcVc_LehU8YJwjCGA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542598914494\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('5267d7cc-ad4d-49a1-98d7-3700ebcc2ad1',0,1724835353,1724835353,'csp-report','backend',1724835352980006,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&noView=1&returnUrl=https%3A%2F%2Ftraw.ddev.site%2Flink%2Fparameter-parts\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/link\\/parameter-parts\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-OknkJW_f1LrAa2zHITdTvEB4BX9nHS8R_R4vpYct4uO1G4Ic8Z0LKQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1724835352980006\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('55b516b3-1d5e-40d9-b69e-1d5d271d7782',0,1718541588,1718541588,'csp-report','backend',1718541587874758,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7&showPreview=1&popViewId=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-eTixwyjus8OCujFOAhNMEUHAzwbhAyVQlh9cp3uyI66wimDWQ7wZ-A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718541587874758\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('5631f13d-4c2b-4e63-9fcd-64c1b29bc480',0,1721245877,1721245877,'csp-report','backend',1721245877094132,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-4gXZXafu6kV0hj13kcXk03Vfm6wzJLQ1L9AJLTt4Jr0MwAYPGLe2GQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721245877094132\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('5a38fb37-6441-4496-8ca4-a8d0c04db086',0,1737973489,1737973489,'csp-report','backend',1737973488500565,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-5Qd8H9lifpRg0g0TI9kfoL2WKXkPhpZTioSOt7mTp0ZrIAwH_b95gg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973488500565&requestHash=269651feb1ed5c673ab80a14b134b0b558a7c34d\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('5b7ebc69-d6e8-447b-9c1f-227f30e2d883',0,1725459158,1725459158,'csp-report','backend',1725459157512240,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%23element-tt_content-31\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=20\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-B_JxorcvLDTBjRDtrm12nSJCs4a_SOeSUdPSyr2aUa014Sf9y510eA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725459157512240\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('5c3e301d-b38a-4ef9-bb15-baf5bb20c5c1',0,1723626180,1723626180,'csp-report','backend',1723626180397336,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-cNuGEadtfWx_jj9MzdtMmP3yjfGsAOuqskAZS1oanoB5T4Pr2O_7yQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626180397336\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('5de6852c-1e06-40f1-af90-2cc1c8a62801',0,1723626889,1723626889,'csp-report','backend',1723626888801335,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-6%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-HCKA5gx8ezeUYEQGOiFmX0B3jskMtBGh4NoyKs67ZF68j1g3CY0Exg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626888801335\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('61bcd855-bd4e-466d-8967-7b6ed5a44e88',0,1730977154,1730977154,'csp-report','backend',1730977153682465,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/130.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B25%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=25\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-HlAAy6MwuPXEQVTnOcj8uwpxKl3KWBfa7LXyZSPmSkE74pm2ODkTYw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1730977153682465\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('624e13c8-249a-4edc-b0d5-1e01b9cd4ada',0,1730977166,1730977166,'csp-report','backend',1730977165750433,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/130.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B37%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B25%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-OHMkMqTR1yyiadwK0oNHGsEoysHIFACXFZGLO4H0HMCn7PmAhnZljQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1730977165750433\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('6313441c-aa6b-43a5-99b4-78cd87280cb7',0,1718542595,1718542595,'csp-report','backend',1718542594835478,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-5\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-5\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-MgitKb9EsLqBi6gaB6QX0SgfEOcl1ZIz7wgpbOQVv_fdAAvsbLwSIw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542594835478\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('63ddda5f-6f33-46f0-ae84-b4d798a837ad',0,1723626985,1723626985,'csp-report','backend',1723626984607494,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-14%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-dTAm6qcNkg5tPTVQ-Qx-7dlyWE1Q6ckXLbByrfotlVTeTSqYp5Cn3w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626984607494\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('64131d30-2795-4503-8f0e-dbc9a587a21d',0,1737973535,1737973535,'csp-report','backend',1737973531422820,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-hp4CDVsK5jvz8Dg6fXpVXy1jeU21sHirIQmpv7dE7X3s72gpPskYHQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973531422820&requestHash=e33c15f213d171a393a6aeaf55b01a4a02695e59\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('64c41c44-11ba-4112-a1b2-3ba43e325550',0,1737973463,1737973463,'csp-report','backend',1737973459506195,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd&showPreview=1&popViewId=29\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-b7FSG2M9w-VCnM6b5QW-5yPzfXHtauCRK_DM09U_XkBeDFAAMTXpew\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973459506195&requestHash=b0d0549326c9f86fe1108a23e035d90543827bca\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('64c899fa-8e27-4264-810b-3e06b6a9f325',0,1725459166,1725459166,'csp-report','backend',1725459165898580,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%23element-tt_content-31\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%23element-tt_content-31\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-q6FnYvrq48c7UB2sQlF8m7wslN0B7tuw589MGgrVqGzDpzS4y8tecA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725459165898580\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('661ebfbb-5168-4a73-9093-231a424f5afa',0,1718547172,1718547172,'csp-report','backend',1718547171998683,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_extloaded&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-XAp6Si6GSeCXYiogM4hd6F5PalVE9Z3mk9BKNgBCBbbYc8LjkOQ6zQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547171998683\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('67b67a33-53de-44c4-b482-f221f0d482bb',0,1725454237,1725454237,'csp-report','backend',1725454236779701,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Bsys_file_metadata%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Frecord%2Fedit%3Ftoken%3Df5a578840a7db80f1f6f4da413de4c5c23257d81%26edit%255Btt_content%255D%255B31%255D%3Dedit%26returnUrl%3D%2Ftypo3%2Fmodule%2Fweb%2Flayout%253Ftoken%253Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%2526id%253D20%2526\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-eLQdxDw7gbLAy2KkNvICAuSPPpHbCEdzEmBjzDLro360dojnN2gCwg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725454236779701\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('6b93c599-a32f-4201-bed2-f1d706c6d0b8',0,1737971906,1737971906,'csp-report','backend',1737971905874793,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd%26id%3D29\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B29%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd%26id%3D29&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-JbKlECCn3lY3Uau_ZV-Z0ZUX9GORHiuP-PEsg2TJDB1NJkGsdBvJKQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737971905874793&requestHash=50266029ebd5d742cd1d1b0d537059af8ad7678a\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('6c239a82-d986-4fe4-ab2c-b69affdb6aad',0,1723627819,1723627819,'csp-report','backend',1723627819156839,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B23%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-wKtXRRyY0O02e3U-wcBFlLILxa0mf7gdBf-cOR0m70-hp7jx3ukraA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627819156839\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('6d6a1078-4dab-4fa5-9320-1fa53d07fec1',0,1737972090,1737972090,'csp-report','backend',1737972087805984,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ALEfKKgfBiP4ME8iRkYalDKCe2swYIK8Ah7GTfnJ32rNsMPRAIbwnA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737972087805984&requestHash=756a8a39bce446e702aff0dfc5636e219e6b7ebe\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('6f6fc9e5-2b19-4a94-b26c-253b1981b08b',0,1723626177,1723626177,'csp-report','backend',1723626174375562,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=16\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-M7AyMzL-Zwh1aBxQ7JOTOdU_olGq_fTGg9KBPIMmdC9BUETktPYVIw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626174375562\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('6f777e4d-939a-4123-ab3a-f98105a4f7d9',0,1723637420,1723637420,'csp-report','backend',1723637419679290,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B25%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D17%23element-tt_content-25\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B25%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D17%23element-tt_content-25\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Bb7Tv9waovQX76C79nfTSg1S7vOCKIhYthf40_D8ogu5IYJD63MuLg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723637419679290\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('6f806fcb-3961-4c9a-9c7d-ca23622925ad',0,1747239284,1747239284,'csp-report','backend',1747239284393865,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Df9488a5820f62a957e2d4f508c90e633c10393bb\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B31%5D=new\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-v1QHR8HuEiETR09AWMriC0-IwJiiYYly4GKQA5aeLdgDnPkM40JvBw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1747239284393865&requestHash=ac8667a41070c4e0ba0f19c56b3cdcaf44cb0d63\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('6ff802bc-4f3b-4758-8071-55cb9543da87',0,1721246251,1721246251,'csp-report','backend',1721246251436772,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce--BA3tHJRVhb5mB0rbI3019F7smDjwViiFylQ1SHZTMTxeusi7KNHkA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721246251436772\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('702b0786-e435-4007-914d-272938018a33',0,1725455160,1725455160,'csp-report','backend',1725455159387765,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Bsys_file_metadata%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Frecord%2Fedit%3Ftoken%3Df5a578840a7db80f1f6f4da413de4c5c23257d81%26edit%255Btt_content%255D%255B31%255D%3Dedit%26returnUrl%3D%2Ftypo3%2Fmodule%2Fweb%2Flayout%253Ftoken%253Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%2526id%253D20%2526\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-eYpakXSI4wUgu1Z25MKqPaaMckldchKi9dirGG7kuNAJl6bug4_xUA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725455159387765\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('706ccdf2-5b00-45bc-b239-4f7de16372be',0,1723626776,1723626776,'csp-report','backend',1723626776530279,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-YkQmrnN04N6U2DJLbvXDuFPkznq65Kj8ST-SmAAJ9noXpNeyBoAMNw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626776530279\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('711000d4-5de2-43b9-8500-0f09159245f6',0,1737973556,1737973556,'csp-report','backend',1737973555901335,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-_Ck_Jt_aqdqPU6Ufm22UaDh95cOtl0_zpkulCHQQcF4h7IeioLj0Vg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973555901335&requestHash=c08f9d4caebeb5cb2d2060b9ff1bdc7bd4f1d804\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('72f29e29-dd87-4787-8d5f-e47e402a0347',0,1749546025,1749546025,'csp-report','backend',1749546024852227,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-40%5D=new&defVals%5Btt_content%5D%5BCType%5D=text&defVals%5Btt_content%5D%5BcolPos%5D=100&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5Btx_container_parent%5D=40&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D0e0a5e50beeabdea679e75fd391554ed8deb7b60%26id%3D28\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=28\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\' https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de; script-src \'self\' \'nonce-TPAqbLIGhGqyIf3A5USYsikbXWQYjpNlEKWU4SBrkENpbWsw3HA87Q\' https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1749546024852227&requestHash=aea4f5d2e0b458ef11b0992c3eaee54b3a152ea6\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":6,\"column-number\":2002,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('73199507-6e04-4a09-83c6-fe699c4be797',0,1723627728,1723627728,'csp-report','backend',1723627727706771,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B22%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B22%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-hS9X4ntjS-KQxIw4sp9DfRyu74QJCAY9zQeozoOpwPd46Or4XIvTIA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627727706771\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('73f1036a-8ce7-4c6f-8a84-843f31f4dacb',0,1723627356,1723627356,'csp-report','backend',1723627355404338,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-59WJ1wnUbmnt_f0bdsV15IA6mBiB22ap5goeRxqQhUHCGXC8vhUhTA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627355404338\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('75de31ff-afd3-4d4e-a0b8-293952e17cfc',0,1723627534,1723627534,'csp-report','backend',1723627533334344,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B17%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-17\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-nNqQUh8Uk7BxiRROp4RIGjMUFAbpL-ZPAxtmbnliI_vHJ0vXrbkTqg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627533334344\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('7d2b55ee-77f4-482d-a913-015f6c2b726a',0,1728293854,1728293854,'csp-report','backend',1728293854139028,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/129.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-aLu3FH5-XpZUMr-4ppd9pkpLBFHs0_P3yQbn1GSjrV8QdK-ELiLa9w\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1728293854139028\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('7f139d7b-161a-466d-b379-bc27d865eaf6',0,1721204902,1721204902,'csp-report','backend',1721204902145980,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-_iTUxcyWg9Qix-TEE_jwpvkBs91elX_d12rhG5VD1qgG9vE7zwy3ug\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721204902145980\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('7f5ada4f-2f8a-4db0-8497-d094942299b3',0,1730977167,1730977167,'csp-report','backend',1730977167077155,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/130.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B37%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25&showPreview=1&popViewId=25\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B37%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D3b95df0749206432f5adb110fa913fffe2fc67b8%26id%3D25\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-MTrf9sUUWOFA9FnHSy5HvyVgUhsGTsmbjNnOo5xFyCOLOFuGaQpg5A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1730977167077155\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('80bcd695-bca4-43a2-a98c-50b2e5c5be4b',0,1723627802,1723627802,'csp-report','backend',1723627801276335,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-e-KK9l1Pdyd3nR990Ymrp_O3xbMFDNfUuQFo0QBLDq-jf-mvjHl5Xw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627801276335\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('82ad0fb8-1fa6-474d-b2f0-6eb55f67d8f3',0,1737972104,1737972104,'csp-report','backend',1737972104156682,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd&showPreview=1&popViewId=29\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-PRLpb8-TI6L2WczEnr1F5TfoYBAA3uDkJn_3AtQlEYa7eh14kKDJ8Q\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737972104156682&requestHash=efb56ea0a41af263db09e8dc5cee2e373360622a\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('84631cac-8d9d-442d-8465-66b44c9b3d17',0,1721246231,1721246231,'csp-report','backend',1721246230572983,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=22&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-OpiWmaSvIXm0rWoywUDBWAPYq6Q2mC354IlMUipnZdySa8AnCwhv6Q\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721246230572983\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('8470eaa1-c47a-4b1b-863e-619457b208af',0,1737973501,1737973501,'csp-report','backend',1737973501464941,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-twpHZEPiKbkkp0JrLjHRvV6IaldIVEgzGRGyseaqG91XZu8sg6PM0w\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973501464941&requestHash=5e38c3915929531e98b9478231bbb25b3e042158\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('84af861e-707c-4aa0-a0b4-d47968834417',0,1723626600,1723626600,'csp-report','backend',1723626599763026,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16%23element-tt_content-9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-6gMBC1EB6ehCGK6lHRaMFF7oy4xqvLnabZE56i9VzISXtW0Mjc3xJw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626599763026\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('877ebf23-16c8-4b51-8a41-b60953d7f11b',0,1723627345,1723627345,'csp-report','backend',1723627344968024,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-qZs2WG9qwAImML65wpYZHyMftdjaCqZJ0FSeuCxx55ErvEEaIMlRUQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627344968024\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('957a8784-c055-4acd-a3d1-ceb9b78ac8aa',0,1718542577,1718542577,'csp-report','backend',1718542576681814,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-x7YT_U5tZeRvSrYMRF8sE4x2wuErcZiOkuGrcPxEfUJSDMx-rR397Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542576681814\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('97d2da82-3704-4b1b-badc-cc725813e362',0,1718542620,1718542620,'csp-report','backend',1718542619599430,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-3\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-hJlkHiqZ3urc8J8TC9ScmrRlxk4qi3Rq9HmHGgwrHPPXDkDbHf6NRg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542619599430\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('9a005ae4-5cf4-4f24-8262-946fe98078ee',0,1723636949,1723636949,'csp-report','backend',1723636945750270,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B17%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D17&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=17\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-WtAp7auIpa3ro_4V1CuMWu5Oo_AR0AsbFlBXOTgAoYkuvjtFQ_TXfA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723636945750270\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('9add80a3-a7a2-407d-9773-588db5f96d91',0,1718547606,1718547606,'csp-report','backend',1718547606125881,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%26%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-pDh6jnWIlA7H8gyTUJZKJE4_AgNnllGpa4eiOBRsol4oU7TkoOGINQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547606125881\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('9cde7f86-96a6-4e96-aa9a-03e8c641d66d',0,1723627643,1723627643,'csp-report','backend',1723627642285112,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-20%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-sLbmkSD1jHcKYvSofA53Gw0409VBfhq7AoYZpMEpOorfS7w0PmZT2A\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627642285112\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('9efbcf18-7d22-4ddc-99bb-9eb1ddf89b08',0,1723623595,1723623595,'csp-report','backend',1723623594553199,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D16&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-iklLRWVhBd2Pja93sTnxLUHccjVmrNjNbeklj0sTJzY0te9csV8ikA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723623594553199\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('a0c00e4e-64c0-41b8-8241-293a09967a35',0,1749545992,1749545992,'csp-report','backend',1749545991132357,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-40%5D=new&defVals%5Btt_content%5D%5BCType%5D=text&defVals%5Btt_content%5D%5BcolPos%5D=100&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5Btx_container_parent%5D=40&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D0e0a5e50beeabdea679e75fd391554ed8deb7b60%26id%3D28\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=28\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\' https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de; script-src \'self\' \'nonce-DHjVENWSRzSCy34WtXvA1H4aorJ7EEZXyAi0Hf9iLRgqDgxD9TUvQg\' https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' https:\\/\\/oaidalleapiprodscus.blob.core.windows.net https:\\/\\/cdn.discordapp.com https:\\/\\/picsum.photos https:\\/\\/fastly.picsum.photos https:\\/\\/ai-suite-server.ddev.site https:\\/\\/api.autodudes.de data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1749545991132357&requestHash=ff51faf49e0356e7f41912588caafad0eed3aa5b\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":6,\"column-number\":2002,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('a802c7b6-c341-4f97-8f7a-b8cb75851f9d',0,1728299631,1728299631,'csp-report','backend',1728299628921047,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/129.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B24%5D=new\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B24%255D%3Dnew\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ZrQYHYIFcgtN-nWQQZXQYXAg_et1UYC2lCxNp9DEEUH8g0FZyYpNTA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1728299628921047\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('a807c3fe-4134-4c74-99f1-2e5e9e66856e',0,1723636988,1723636988,'csp-report','backend',1723636987826705,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B25%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D17\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B17%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D17&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-9EP_CxgZw1wiyIFOygiceJlsQPKhhckPEnwOgZ3n4bIe2urTmN_NYg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723636987826705\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('a9f88683-61ee-41ef-b496-97133df8e564',0,1718541261,1718541261,'csp-report','backend',1718541259572922,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B7%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-N2s5_ps8j4Ac-zXrJexJ-pDpKUIB7vmj_TTcrKl9DXAqkbcpHFJqkw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718541259572922\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('aca05a0c-5c85-4f11-b670-c8f930b09cd4',0,1725445731,1725445731,'csp-report','backend',1725445729689201,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B20%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=20\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ySoKeMw5BdlPAOxrejh_Q7VgQ6nFQFQek0-jCTWdH-hVpCAjAnRyOQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725445729689201\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('b04419ce-adb5-4bc9-8120-7f3b69bc916b',0,1737978643,1737978643,'csp-report','backend',1737978641885820,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B39%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-7Pwxlm2DAKgnSoUIxOWaE3vAQdShbq4CuP1Mgg1G5FGTey4uauMFqA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737978641885820&requestHash=3f359486c26018ded31ae08ff155e56ade5de408\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('b0964a54-42e1-4b69-9abe-bc8318902d64',0,1723627585,1723627585,'csp-report','backend',1723627585042138,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B19%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-18%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-c1XEC9rXaPlFPNOL8RG7iRsyfFCYeUS4Dbu63PqOyZsMXNo9WPLGaQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627585042138\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('b1e7afcb-a6ae-45f1-9218-ec60ec701f6b',0,1723627329,1723627329,'csp-report','backend',1723627328242970,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B17%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-14%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ookLTZ05DjJYZSxPDSiTVRX_wevF3p3hhCYWjtiBQz8zXQ9hjAPYAw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627328242970\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('b547a12b-f061-4f60-b98d-a5acd51ac281',0,1718547316,1718547316,'csp-report','backend',1718547315710399,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-z2pLr43x6SZEsxAJrEcNhZeT3H4ncb5p_fArw0_NMRjD6kSqxy8lqQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547315710399\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('b5f03a40-3d27-4a20-8614-86c0e0146ecb',0,1737973581,1737973581,'csp-report','backend',1737973580698951,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-La0g2Zl9HkJGwCZnD7NwOTXFEKfXPK8fwThzF6BDOwsQw3R5KWDr_A\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973580698951&requestHash=f95ba0ed84a4fba45e8fe42e75711bce845d14c3\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('b7cf91c2-d370-4760-b3d8-0ccb32024d8d',0,1723626871,1723626871,'csp-report','backend',1723626871499688,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-6\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Mx5SiFRfDtz4YW7r7GNDo1-0MopmWrnSUGoMmNAifQdEBsIaolzYeQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626871499688\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('b9fc2543-61cd-4c5a-982e-5be61605e4e2',0,1723627658,1723627658,'csp-report','backend',1723627657527136,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B21%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-20%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xg1FOzSsSEHBi8gDjn6RAYheV_zWalH5-o6KDHvgGMfwiuLXvpO0Hw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627657527136\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('bbdacbf4-7281-4484-8b1f-d1c9a5b5707f',0,1725453771,1725453771,'csp-report','backend',1725453768434199,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B20%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=20\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-rw9LjwwPBh1xZVayF4E_1yRbX5z7nN1UaI-btRBJsL9OuLV9tVdnRg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725453768434199\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('bc49d595-04c8-4a8d-894c-49c4feb7d469',0,1737973516,1737973516,'csp-report','backend',1737973516019062,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-CjnQpNL_lOwySFigAm8F4jEmlyy2axmUDyD7tbOL5BuLAanBQrVNJA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973516019062&requestHash=4c3ea2b006f8ece7f8bde1dea8b04924c2a22ef4\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('bd094b49-4879-4aee-8606-e90ce3dba02a',0,1735643976,1735643976,'csp-report','backend',1735643974862730,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Df63dc9a7dd1cd60192a3255b6570fb9069ce15ee%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=22&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3Df63dc9a7dd1cd60192a3255b6570fb9069ce15ee%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-xO1eTvZ5B5sKKpWEVs_s8Wfsfws2bQP0JE1AQ8iUjUJhZAljir9lLA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1735643974862730\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('bdb56ae2-8a7e-477c-a3b4-7ef4d629b1de',0,1737973571,1737973571,'csp-report','backend',1737973571278890,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Gd_zDHvcYfcKB43kkBdIc_0qqTmxhCryzXS0uWdvCzmIXMyv1U2oVQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973571278890&requestHash=d86bcc83fcb357462581b55a43288555e5b94ac5\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('bf06801b-a68b-4eac-a8e7-c9aecfe9f010',0,1737973549,1737973549,'csp-report','backend',1737973548554486,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-LL9xAUIUMhN6DIrgutJUET1zuV8B_Qa9bzvUbw4pupfD4LnPubHamg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737973548554486&requestHash=b1df39dd002624a554a924d4e943412597070044\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('bf0ec589-276e-4f4c-adbe-3ad9929a168a',0,1723627568,1723627568,'csp-report','backend',1723627567822057,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-18%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-KRF2vk9G9AjK-F7obGcqvdnRdAyfaBKsA72fCzkrMcn1NcNC5lXMXg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627567822057\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('c1c8785b-a3df-4bc6-bdd7-eca6157c790c',0,1737972102,1737972102,'csp-report','backend',1737972102430805,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-eJlmW44aVoGZwyr7XP0N2aGARCdRlUY6ZxkpHC1EbcNva-xhIvaEtw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737972102430805&requestHash=44602f934c142a7f55b6d965a6efdba8834bc80c\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('c20c8a6b-67c0-43ee-9ccf-5d8c571c927b',0,1725456117,1725456117,'csp-report','backend',1725456115758699,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%26\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Bsys_file_metadata%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Frecord%2Fedit%3Ftoken%3Df5a578840a7db80f1f6f4da413de4c5c23257d81%26edit%255Btt_content%255D%255B31%255D%3Dedit%26returnUrl%3D%2Ftypo3%2Fmodule%2Fweb%2Flayout%253Ftoken%253Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%2526id%253D20%2526\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-hcdIhMGTuc_SnHYU4BmT0qahFVLBfSnjE10Fd0_-lO3b8RMVY3uNug\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725456115758699\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('c28163c7-6e8d-4cab-9c5e-e5ff738402b1',0,1723627626,1723627626,'csp-report','backend',1723627625530745,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B20%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-19%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-38nbW8GU6772KVxDSaW9G9EYBjUUNJZ6_qSswCzKt_ua7yxvAZfONQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627625530745\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('c2fbb0e7-a082-4d6e-b61b-b40af9f57355',0,1728293887,1728293887,'csp-report','backend',1728293882189453,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/129.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D75a1cd90dd93b587120c3b89e88b26e0045cc5b1%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-9t-iX7aay8GkK_8a9THNgBUPoW4RJ_MNzaNEy8CffyhRTEqtpyl04g\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1728293882189453\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('c3af7406-1adc-43f4-8a70-29374f5af130',0,1723627402,1723627402,'csp-report','backend',1723627401941821,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B15%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-15\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B15%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-15\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-rrrA6EoXj5d0AfgOqDrb4ls6ACyZ5NPVeQTTAMJyMXCc7h7H5krUfw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627401941821\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('c5e35633-cfef-4ca1-ac3f-b253984fa270',0,1721246241,1721246241,'csp-report','backend',1721246240565208,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=22&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-SOMV15SOJoHQZbuxYOeqg17K-MRYNKYpvEMKgIUVpkD5Yf0qK8I_rQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721246240565208\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('c91e8a2c-b7c1-4f32-9dbc-91a14eae7782',0,1721244429,1721244429,'csp-report','backend',1721244428800885,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B24%5D=new\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B24%255D%3Dnew\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-mjZBsCFwum2fJ7o3m9RKdP84F18Yp7SOW2sSqfSkgzSfUTYyeGZSvQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721244428800885\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('cca09f84-a368-4bca-8fc6-153f1bc85f81',0,1725445704,1725445704,'csp-report','backend',1725445703940817,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B20%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=20\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-1bKwk2PiQ895hxDRcmwqEaKdTXsozfFENLNxK1zT4dODYGh4tuTKcQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725445703940817\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('cd96daf6-e050-4a63-b066-ac5e760f22cd',0,1721204803,1721204803,'csp-report','backend',1721204802699206,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_address%255D%255B22%255D%3Dnew\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ttzy_Zbo-OCBTT_G0iJeJUUleTV78iCCPLbuqwnCFoZgJkuD3CwWpw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721204802699206\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('cdadb7b2-45db-409e-96ee-c01fe55d21d2',0,1718542609,1718542609,'csp-report','backend',1718542609032815,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B4%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-4\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B4%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-4\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-RIfbjb7B2DI_fX8QxpK0Wt8MpqNuYqqLauhClYXIQLmnStNeiVLY7w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542609032815\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('d3c38451-f93a-435f-a336-8e8273e13e2e',0,1718547209,1718547209,'csp-report','backend',1718547208845676,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B9%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-X4CgCk2tviz7mcpWb9iD58ocytsmq-glvNYnys1XEKWghetS3G5XoQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547208845676\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('d767faf9-ccc3-4cad-af73-a94ae3d8c103',0,1721246249,1721246249,'csp-report','backend',1721246248946110,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B3%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/list?id=22\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-kILEjjbZF6YtEdowWAVJ548BI2c4XBa_yeYhM8bxd2rBgpglATywUA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721246248946110\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('d7dc41e5-487c-48be-bd82-9c69eb3db2df',0,1718547320,1718547320,'csp-report','backend',1718547319549025,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%23element-tt_content-6\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-e9Ccf9dkzLTiCFzABPdsy64B1NoksyWFRHKQS0bEqDsZSS8aaL5weQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547319549025\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('dc0a113e-2d08-47b1-8518-05429c7c6b54',0,1723627337,1723627337,'csp-report','backend',1723627336510524,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B16%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-16\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-EuczDeKFu6xwBxLEwZVMZ31FkYS2KDqV0OiJ4vKEaJZ4PZulJtcCwQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627336510524\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('decee487-a50a-41e6-8195-83142b3d79ec',0,1747240982,1747240982,'csp-report','backend',1747240978415524,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Df9488a5820f62a957e2d4f508c90e633c10393bb\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Df9488a5820f62a957e2d4f508c90e633c10393bb\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-IfbFx0w8JwAACGsBR_LRj6ajTkFSoQk6L2UbqXvyMkYv0kKCvnyKZA\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1747240978415524&requestHash=89e1a87e3d59b4ed91bc39b620c60c6204f0b416\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":6,\"column-number\":2002,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('e4fabbce-88a4-4f3a-81a7-a210b3aa6c4b',0,1723626977,1723626977,'csp-report','backend',1723626976799335,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B-14%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9&defVals%5Btt_content%5D%5BCType%5D=traw_daterange&defVals%5Btt_content%5D%5Bheader_layout%5D=3&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-l_4cuUpsFM7Z9So_9YfGTC9qk7vlmHwvLKaE9EN6XVqKPk8OSAMDNA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723626976799335\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('e7905ec9-ac2b-44e3-b5fe-20117764ce4e',0,1723629272,1723629272,'csp-report','backend',1723629272093872,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B23%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9%23element-tt_content-23\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-UgSudOtuzfqJbcC45HJr1tN-V2hNCyZ-ITFcoHcSVX69E9YvdnE42w\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723629272093872\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('e7b42cdd-c2c0-47da-a7e5-838f4202d12d',0,1721246234,1721246234,'csp-report','backend',1721246234438905,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B22%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-FNj76uthKmnB8Aa2utyjMhQobEsZg6fuDsWOqLVm9MrEUdqqKMAVRw\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721246234438905\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('edd8af6f-0513-404c-9f89-eab323fcfe54',0,1718541373,1718541373,'csp-report','backend',1718541372450176,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B2%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B7%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7&defVals%5Btt_content%5D%5BCType%5D=textmedia&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-yTZCtN-70a_MoNsENTYtr3RQAovtInEtknOOdzkyJ-psrI7TKPaa1Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718541372450176\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('f1d63d1b-08f7-4c8b-8067-4c2d3c74f436',0,1718547627,1718547627,'csp-report','backend',1718547626714606,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%26%23element-tt_content-6\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B6%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D9%26%23element-tt_content-6\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-UQnXJ8PnW52BlRAfrqb5k2--dT3B5Li3JZsPio4pszVPx0g43E8k1Q\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718547626714606\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('f3e58ee6-dc5c-45ee-8e8e-6bd2ed72a77d',0,1718542622,1718542622,'csp-report','backend',1718542621542108,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B5%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D7cb1461f6b56b5342812b34e97a2a53ebac612e3%26id%3D7%23element-tt_content-5\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=7\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-j6FllI3d0oeBCa-SYPDDmNV33AFpk5b6hOtJCrdovk7-752U8dWOVQ\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542621542108\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('f47d6572-9db6-4483-9ffc-95ccf7ebfe26',0,1737974460,1737974460,'csp-report','backend',1737974460228328,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/131.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd&showPreview=1&popViewId=29\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B39%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D4fb4aca901bacaa21e6276141ef7e3f5752d3ebd\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ne9uHF9hoKnghIqEkB1GHAnMjVzqyKK2DmzVvRr9FV-zKGiPczsWNg\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1737974460228328&requestHash=7bd572198b222db79db8a79141ecb554c542e1ab\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('f54ee30f-4718-43c2-af12-ce95b166acac',0,1747239266,1747239266,'csp-report','backend',1747239265431333,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B31%5D=new\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btx_news_domain_model_news%255D%255B31%255D%3Dnew\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-Do4ERDw0psyhJY6Qjc_ZrF-rOOjt1Y_1Ecr3k2UJK9kTOuqrhNEZ3g\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1747239265431333&requestHash=e8dc9e4eef72b6817a3a7bf386582e10877f1ab7\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('f9366f24-4496-41be-826a-8f1afa04fe88',0,1747239161,1747239161,'csp-report','backend',1747239161075360,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/136.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btx_news_domain_model_news%5D%5B31%5D=new&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D901217e11501c2b55981013c007e336123550101%26id%3D31%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/new?id=31&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D901217e11501c2b55981013c007e336123550101%26id%3D31%26table%3D%26pointer%3D1\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-5Crs9rtxJSJB9B-0Xid65L-fur6Psu95TtCQTzrsHBu65_VpThnahQ\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; frame-src \'self\' *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1747239161075360&requestHash=ba946e9f9141cfd6565502a49ca0a7dafeb8cbc4\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','8cd3bd75b25fdd0fc57c43a53a6a44ee39a58086'),
('fb285960-9e87-4fd7-b6a4-af19e6e588a9',0,1721245875,1721245875,'csp-report','backend',1721245874585240,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/126.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_address%5D%5B1%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flist%3Ftoken%3D8a2d418b17d0c93b0473f06ddc26a6eebc4daf4a%26id%3D22%26table%3D%26pointer%3D1\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/list?id=22\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-pq9iloa45_VEGB5rlpE22qEoEkecVOCbXnVCnIE3dy8cMMhyJeXSng\' data: https:\\/\\/*.openstreetmap.org \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org https:\\/\\/*.openstreetmap.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; connect-src \'self\' data: https:\\/\\/*.openstreetmap.org; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1721245874585240\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('fc7d4127-6954-467e-a137-5a22c8a3814d',0,1725459078,1725459078,'csp-report','backend',1725459077621435,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/128.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B31%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3Def3bd4cf835c955eeef3bd3c9d456c5096ae9f20%26id%3D20%23element-tt_content-31\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/module\\/web\\/layout?id=20\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-MXFc0gB2Or3k3rTkYsgPXQ880gyhVyKRr0MfSvMlizUGK-Liqa94dw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1725459077621435\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('fc82ea9f-0298-4cd8-9415-8fdbb31036f7',0,1723627852,1723627852,'csp-report','backend',1723627851435577,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B23%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B23%5D=edit&returnUrl=%2Ftypo3%2Fmodule%2Fweb%2Flayout%3Ftoken%3D5ac2d7b1e82787995b2d90e5979d8f5b16cfd0bb%26id%3D9\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-cfHVEvdMrbQCwEdAmb2CpKOp9GvHBE8KkzVSAAyooVhlm9uWLmZycw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1723627851435577\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0'),
('fe71a33b-a5c9-47b1-ab94-3025076b6c97',0,1718542527,1718542527,'csp-report','backend',1718542524345014,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/125.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/traw.ddev.site\\/typo3\\/record\\/edit?edit%5Btt_content%5D%5B4%5D=edit\",\"referrer\":\"https:\\/\\/traw.ddev.site\\/typo3\\/main?redirect=record_edit&redirectParams=edit%255Btt_content%255D%255B4%255D%3Dedit\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-ojbfoDvNU1ywfMWtfd2ASeXUaDcuaw64QRGd8e0oRzDMdd8C6WiSUA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/traw.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1718542524345014\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":1,\"column-number\":33690,\"source-file\":\"https:\\/\\/traw.ddev.site\\/_assets\\/937be57c7660e085d41e9dabf38b8aa1\\/Contrib\\/@ckeditor\\/ckeditor5-inspector.js\",\"status-code\":200,\"script-sample\":\"(function anonymous(\\n) {\\nreturn this\\n})\"}','e0b8ddc844315d3497b9c7e51825ecedef5ccbf0');
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `source_host` varchar(255) NOT NULL DEFAULT '',
  `source_path` text NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `creation_type` int(10) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` text NOT NULL DEFAULT '',
  `target_statuscode` int(10) unsigned NOT NULL DEFAULT 0,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `lasthiton` bigint(20) NOT NULL DEFAULT 0,
  `integrity_status` varchar(180) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`hash`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('08bc8084fc9ecee647a781018c70ce04','tx_powermail_domain_model_form',1,'pages','','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('0a76de7e82308344d04ec83d1ad5bb10','tt_address',1,'email','','email','2',0,0,'_STRING',0,'traw@traw.ddev.site',0,0,2147483647,0,'',0,0,2147483647,0,0),
('0ef4b28b6ed4c915c98b6bb60933c0f7','sys_template',1,'config','','url','2',0,0,'_STRING',0,'https://static.mydomain.com/',0,0,2147483647,0,'',0,0,2147483647,0,0),
('123c60a0713af64348d616d16e35e31d','tx_news_domain_model_news',2,'internalurl','','typolink','1c9554e2bd14cc603bdcce7d4da126e8:0',0,0,'pages',6,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('13e3f775f5fe55e34e6c3053fc81a294','sys_file',7,'metadata','','','',0,0,'sys_file_metadata',7,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('1478533a17952c2c5bd390090ffcf404','tt_content',31,'assets','','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('15fd99ffa7357c9b1d4290d396f2780f','sys_file_metadata',4,'file','','','',0,0,'sys_file',4,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('1b9b71f8f844d62915c3a760c90166ee','tt_content',10,'header_link','','typolink','f37f33a477f4d547c6cd4613f67ac230:0',0,0,'tt_content',10,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('209d2b59c71f7eed756adfcdfa577cfa','tt_content',30,'header_link','','typolink','8de9d296cab54ce4cc55288010480fa2:0',0,0,'_STRING',0,'07131 / 333 55 12',0,0,2147483647,0,'',0,0,2147483647,0,0),
('21258650f973214ea36749d6f1e0e877','tx_powermail_domain_model_page',1,'fields','','','',0,0,'tx_powermail_domain_model_field',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('22e73aa869347277eb1f98fc138067d2','sys_file_metadata',2,'file','','','',0,0,'sys_file',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('26ed2d90ce2e2f8e7c9fa0d7e4126147','tt_content',38,'pi_flexform','sDEF/lDEF/settings.singleRecords/vDEF/','','',0,0,'tt_address',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('363a9e113503620ecef9238f87707287','sys_file_reference',3,'uid_local','','','',0,0,'sys_file',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('39302b34fcc68b7cc0dab6f16be7c324','sys_file',8,'metadata','','','',0,0,'sys_file_metadata',8,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('42bc70364f3f8c60da365be70ab81292','tt_content',11,'header_link','','typolink','adafeb4f3f807f83ff10be190c93ddae:0',0,0,'pages',16,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('492dd930b8f60827688eb9f5332f18c9','sys_file_reference',1,'uid_local','','','',0,0,'sys_file',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('55231cdec3ca5e99358ca243da17f158','tt_content',36,'header_link','','typolink','7b7929d62974f30b2373e617e7f0b1a3:0',0,0,'pages',15,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('5cf62de176f58998d1750ec070eb9269','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('5e282bf8b983d49e05509b0766b68fd3','tt_content',37,'assets','','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('790ff16e0bbecee48a36b95e5eb6414b','be_users',1,'usergroup','','','',0,0,'be_groups',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('825aada1766f403b76e9adc3ff3908d2','tx_powermail_domain_model_field',1,'page','','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('83af79dd2cebb1569ddf61622df52bcb','sys_file_metadata',7,'file','','','',0,0,'sys_file',7,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('8d20646af662092f2ec1cf930987beb0','tx_powermail_domain_model_page',1,'form','','','',0,0,'tx_powermail_domain_model_form',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('9007b97bbb373a088e39dbfd723a9094','sys_file_metadata',6,'file','','','',0,0,'sys_file',6,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('9623baa766db7f3edb61b54f05d23e27','sys_file_reference',5,'uid_local','','','',0,0,'sys_file',4,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('bb07476d9b0172491715d5ea40709c28','sys_file_reference',6,'uid_local','','','',0,0,'sys_file',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('bd5e5bd53415f212cde4bfb5923cc8e5','sys_file',4,'metadata','','','',0,0,'sys_file_metadata',4,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata','','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('bef1c86c2909cb11830eb72f1e834570','tt_content',11,'header_link','','typolink','5f44fbdbc88a146db7f68a6a5be6f706:0',0,0,'tt_content',11,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('c47a797b1e46b346553bd44455bbef56','tx_powermail_domain_model_page',1,'fields','','','',1,0,'tx_powermail_domain_model_field',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('ce5d84aa39bed2c184ece9ab314fecc2','tx_powermail_domain_model_field',2,'page','','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('ce9f19b6de747ff379a24086c1985f85','sys_file_metadata',5,'file','','','',0,0,'sys_file',5,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('d860d9389667c92145871d401a40f562','sys_file',6,'metadata','','','',0,0,'sys_file_metadata',6,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('da3d88bce1f8d47ee5763aadfab6558a','sys_file_metadata',8,'file','','','',0,0,'sys_file',8,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('e6d1231d15b9b30923b161ff80a14ec5','sys_file_metadata',3,'file','','','',0,0,'sys_file',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('e979f5172b9aa804c27b98c901dc724c','sys_file_reference',2,'uid_local','','','',0,0,'sys_file',2,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('ec21f2e6ecb10e46a67a21d3d2bfbd98','be_users',1,'email','','email','2',0,0,'_STRING',0,'traw@traw-admin.com',0,0,2147483647,0,'',0,0,2147483647,0,0),
('edc0497b285520eb66d76244acb00679','tt_content',10,'header_link','','typolink','7d3904a70910aa09f8c9f03d40a0c1bc:0',0,0,'pages',16,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('f1b141d8d9468fcfaf6a18e0a1fb5cc7','sys_file',3,'metadata','','','',0,0,'sys_file_metadata',3,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage','','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('f9c64f1c71a8b40ffa94f38fcbb366b0','sys_file_metadata',1,'file','','','',0,0,'sys_file',1,'',0,0,2147483647,0,'',0,0,2147483647,0,0),
('ffa602de6cc41aa063aec87c7234f976','sys_file',5,'metadata','','','',0,0,'sys_file_metadata',5,'',0,0,2147483647,0,'',0,0,2147483647,0,0);
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PasswordPolicyForFrontendUsersUpdate','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),
(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(15,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\IndexedSearchCTypeMigration','i:1;'),
(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PagesRecyclerDoktypeMigration','i:1;'),
(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(22,'installUpdate','TYPO3\\CMS\\Extensionmanager\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(23,'core','formProtectionSessionToken:1','s:64:\"44d40e8f0005b347cd0f5a7cf949097268246fcc1b817b6f6b6a2eccae6f465d\";'),
(24,'core','sys_refindex_lastUpdate','i:1738312017;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` longtext DEFAULT NULL,
  `constants` longtext DEFAULT NULL,
  `config` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1735643395,1717852958,0,0,0,0,256,NULL,'TRAW Theme Main Test Instance',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:seo/Configuration/TypoScript/XmlSitemap,EXT:vhs_col/Configuration/TypoScript/,EXT:vhs_col/Configuration/TypoScript/GalleryProcessor/,EXT:tt_address/Configuration/TypoScript/,EXT:vcfqr/Configuration/Typoscript/TtAddress/,EXT:vcfqr/Configuration/Typoscript/Example/,EXT:traw_theme/Configuration/TypoScript/',NULL,'plugin.tx_vhscol.settings.prependPath = https://static.mydomain.com/','',0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_address`
--

DROP TABLE IF EXISTS `tt_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_address` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `gender` varchar(1) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `first_name` tinytext DEFAULT NULL,
  `middle_name` tinytext DEFAULT NULL,
  `last_name` tinytext DEFAULT NULL,
  `birthday` bigint(20) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_suffix` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(30) NOT NULL DEFAULT '',
  `mobile` varchar(30) NOT NULL DEFAULT '',
  `www` varchar(255) NOT NULL DEFAULT '',
  `address` tinytext DEFAULT NULL,
  `building` varchar(255) NOT NULL DEFAULT '',
  `room` varchar(255) NOT NULL DEFAULT '',
  `company` varchar(255) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(20) NOT NULL DEFAULT '',
  `region` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(128) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `skype` varchar(255) DEFAULT '',
  `twitter` varchar(255) DEFAULT '',
  `facebook` varchar(255) DEFAULT '',
  `instagram` varchar(255) DEFAULT '',
  `tiktok` varchar(255) DEFAULT '',
  `linkedin` varchar(255) DEFAULT '',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `image` tinyblob DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `pid_email` (`pid`,`email`(191)),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_address`
--

LOCK TABLES `tt_address` WRITE;
/*!40000 ALTER TABLE `tt_address` DISABLE KEYS */;
INSERT INTO `tt_address` VALUES
(1,22,1735644022,1735644022,0,0,0,0,'',256,0,0,NULL,0,'',0,0,0,0,'','TRAW Admin','traw-admin','TRAW','','Admin',0,'','','traw@traw.ddev.site','+49 1234 123455','','https://traw.ddev.site/','','','','','','','','','','','','','','','','','',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `tt_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` longtext DEFAULT NULL,
  `pages` longtext DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  `date` bigint(20) NOT NULL DEFAULT 0,
  `dateRangeStart` int(11) NOT NULL DEFAULT 0,
  `dateRangeEnd` int(11) NOT NULL DEFAULT 0,
  `test_field` varchar(30) NOT NULL DEFAULT '',
  `tx_container_parent` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `container_parent` (`tx_container_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(2,'',7,1718541587,1718541372,0,0,0,0,'',128,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textmedia','Extension loaded','','<p>This viewhelper checks whether a specific extension key is loaded.</p>\r\n<p>Since it is extended from AbstractConditionViewHelper you can just use it like a normal condition.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Checks, whether a specific extension is loaded','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(3,'',7,1718542619,1718541685,0,0,0,0,'',384,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_extloaded','EXt:powermailcaptcha','','<p>This extension <strong>is loaded</strong>, the ViewHelper should return <strong>true</strong>.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"extkey\">\n                    <value index=\"vDEF\">powermailcaptcha</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','','',124,0,0,0,0,NULL,0,0,0,'',0),
(4,'',7,1718542608,1718542208,0,0,0,0,'',640,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_extloaded','EXT:powermailautocomplete','','<p>This extension <strong>is loaded</strong>, the ViewHelper should return <strong>true</strong>.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"extkey\">\n                    <value index=\"vDEF\">powermailautocomplete</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(5,'',7,1718542632,1718542249,0,0,0,0,'',896,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_extloaded','EXT:my_ext_not_loaded','','<p>This extension <strong>is not loaded</strong>, the ViewHelper should return <strong>false</strong>.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"extkey\">\n                    <value index=\"vDEF\">my_ext_not_loaded</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(6,'',9,1723627368,1718547208,0,0,0,0,'',768,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"dateRangeStart\":\"\",\"dateRangeEnd\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_daterange','Fallback only begin date','','<p>This example only has a “Begin date”</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,100,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1717286400,0,'',0),
(9,'',16,1724835394,1723623594,0,0,0,0,'',320,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textmedia','Parameter Parts','','<p>This viewhelper can extract the parts of a typolink:</p>\r\n<ul><li>title</li><li>css class</li><li>target</li><li>url</li><li>additionalParams</li></ul>\r\n<p>This could be useful for example for automatically creating buttons with the link title as button text</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','medium',NULL,NULL,0,'','',0,0,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(10,'',16,1723626699,1723623764,0,0,0,0,'',512,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_parampart','Testing all parameters','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','t3://page?uid=16#10 _blank my-css-class \"Link title\" &test=123',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(11,'',16,1723626709,1723624163,0,0,0,0,'',768,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_parampart','Testing no parameters','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','t3://page?uid=16#11',0,3,'',1,0,'',0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,'0',0,0,0,'',0),
(12,'',16,1723626719,1723626079,0,0,0,0,'',1024,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_parampart','Testing no link','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(13,'',16,1724835362,1723626747,0,0,0,0,'',128,0,0,0,0,NULL,'',0,0,0,0,'menu_section','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(14,'',9,1723626835,1723626835,0,0,0,0,'',128,0,0,0,0,NULL,'',0,0,0,0,'menu_section','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(15,'',9,1723627401,1723626909,0,0,0,0,'',1024,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"dateRangeStart\":\"\",\"dateRangeEnd\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_daterange','Fallback only end date','','<p>This example only has an “End date”</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,100,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,1723766400,'',0),
(16,'',9,1723627349,1723626984,0,0,0,0,'',704,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"dateRangeStart\":\"\",\"dateRangeEnd\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_daterange','Fallback without dates','','<p>Example with no dates set</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,100,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(17,'',9,1723627543,1723627328,0,0,0,0,'',672,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Fallbacks','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(18,'',9,1723627443,1723627443,0,0,0,0,'',144,0,0,0,0,NULL,'',0,0,0,0,'traw_daterange','Same day','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1723593600,1723593600,'',0),
(19,'',9,1723627584,1723627584,0,0,0,0,'',152,0,0,0,0,NULL,'',0,0,0,0,'traw_daterange','Same week','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1722816000,1723075200,'',0),
(20,'',9,1723627625,1723627625,0,0,0,0,'',156,0,0,0,0,NULL,'',0,0,0,0,'traw_daterange','Same month','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1722729600,1724803200,'',0),
(21,'',9,1723627657,1723627657,0,0,0,0,'',158,0,0,0,0,NULL,'',0,0,0,0,'traw_daterange','Same year','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1722729600,1730246400,'',0),
(22,'',9,1723627727,1723627681,0,0,0,0,'',159,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"dateRangeStart\":\"\",\"dateRangeEnd\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_daterange','Year overlap','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1735516800,1737331200,'',0),
(23,'',9,1723629278,1723627818,0,0,0,0,'',415,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"dateRangeStart\":\"\",\"dateRangeEnd\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_daterange','Multiple years overlap','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,1596240000,1853884800,'',0),
(24,'',17,1723637407,1723635643,0,0,0,0,'',256,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_pipe2br','Pipe|||2||br','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Pipe***2******br','',0,3,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(25,'',17,1723637419,1723636987,0,0,0,0,'',128,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textmedia','Pipe2Br Test','','<p>The viewhelper replaces the string in the text with the replacement (simple, no regex or anything)</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(26,'',17,1723637402,1723637341,0,0,0,0,'',192,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_pipe2br','We need a linebreak|before this','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'We need a linebreak***before this','',0,3,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(27,'',17,1723637359,1723637359,0,0,0,0,'',224,0,0,0,0,NULL,'',0,0,0,0,'header','Example 2','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(28,'',17,1723637372,1723637372,0,0,0,0,'',160,0,0,0,0,NULL,'',0,0,0,0,'header','Example 1','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(29,'',17,1723637413,1723637387,0,0,0,0,'',144,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pages\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"accessibility_title\":\"\",\"accessibility_bypass\":\"\",\"accessibility_bypass_text\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'menu_section','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,0,'',0,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(30,'',18,1723640210,1723638353,0,0,0,0,'',256,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"subheader\":\"\",\"header_link\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'traw_phone','+41446681800','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'0170123456678','\"tel:07131 / 333 55 12\"',0,3,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(31,'',20,1725459165,1725454228,0,0,0,0,'',256,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textmedia','','','',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0),
(40,NULL,28,1749545989,1749545989,0,0,0,0,'0',256,0,0,0,0,NULL,'',0,0,0,0,'row-test','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,0,'',1,0,NULL,0,'','','',0,0,NULL,'','',NULL,124,0,0,0,0,NULL,0,0,0,'',0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` longtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT -1,
  `headline` varchar(255) NOT NULL DEFAULT '',
  `field` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `element_type` varchar(255) NOT NULL DEFAULT '',
  `link_title` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `url_response` text DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--

LOCK TABLES `tx_linkvalidator_link` WRITE;
/*!40000 ALTER TABLE `tx_linkvalidator_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_linkvalidator_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-10 11:26:03
